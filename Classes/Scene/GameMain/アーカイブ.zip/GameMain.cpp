//
//
//	Arumi,制作
//		月光の精霊姫 ルナ 〜 ElementalMaster Luna,
//
//		ゲームメイン Src
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include "GameMain.h"
#include "Constants.h"
#include "ImageUtil.h"
#include "InputManager.h"
#include "SimpleAudioEngine.h"
#include "MessageWindow.h"


using namespace std;
using namespace cocos2d;
using namespace CocosDenshion;



//=============================================================================
//	グローバル変数
//	クラス化しようね
//=============================================================================

// 背景テクスチャとスプライト

GameMain* gGameMain = 0;

TEXTURE g_bgTexture;
Sprite* g_pBg;
Sprite* g_pBg2;
Sprite* g_pBg3;

// 地面
TEXTURE g_groundTexture;
CCharacter g_pGround;

// ルナ
TEXTURE g_lunaTexture;
CPlayerLuna m_luna;

// ルナの実体を画像として表す
TEXTURE g_lunaBodyTexture;
CCharacter g_lunaBody[LUNA_BODY];

// ふぉーすあろー
TEXTURE g_fATexture;
CCharacter g_forceArrow[MAX_BULLET];

// しゅーてぃんぐ ぶれいず
TEXTURE g_sBTexture;
CCharacter g_shootingBlaze[MAX_SBLAZE];


// UIテクスチャ
TEXTURE g_uiTexture;
Sprite* g_ui;
// メニュー画面のテクスチャとスプライト
TEXTURE g_menuTexture;
Sprite* g_pMenu;

// ブロックテクスチャとスプライト
TEXTURE g_blockTexture;
CCharacter g_block[MAX_BLOCK];

// 出撃時に表示させる R E A D Y の文字テクスチャとスプライト
TEXTURE g_readyTexture;
CCharacter g_r;
CCharacter g_e;
CCharacter g_a;
CCharacter g_d;
CCharacter g_y;



// 砂埃のテクスチャとスプライト
TEXTURE g_smokeTexture;
CCharacter g_smoke[MAX_SMOKE];

// ルナのアニメーション状態管理列挙とルナの方向列挙
kLunaAnimation m_lunaAnimation;		// ルナのアニメーション列挙
kLunaMuki m_LunaMuki;				// ルナの向きの列挙

// ゲームモードを分割する列挙
kGameMode m_gameMode;


float gravity;						// 重力
float jump_power;					// ジャンプの強さ

bool scroolFlagRight;
bool scroolFlagLeft;

int g_forceArrowIntervalTime;		// 発射間隔
int g_shotAnimationTime;			// ショットアニメーションが戻るまでのカウンタ
int g_animationSpeed;				// アニメーションスピード
int g_forceArrowNumber;				// ふぉーすあろーの数
int g_sBNumber;
bool g_jumpTopFlag;					// 頂点フラグ

bool g_intersect_TOP;
bool g_intersect_RIGHT;
bool g_intersect_LEFT;
int g_checkStandGround;					// 接地フラグ
bool dashFlag;						// ダッシュしているかどうかのフラグ
int charge;							// サウンドIDを取得するためのint型変数
bool dashJumpFlag;					// ダッシュジャンプフラグの生成
int m_startCount;					// 出撃時のディレイ
int m_startCount2;					// 出撃時のディレイ２
int readySeFlag;					// R E A D Y ? を表示させSEを鳴らす多重処理防止用のフラグ
int g_lunaOpacity;					// ルナの透過度を指定
int m_sb_rotation;
bool ifBlockStandFlag;
bool isInArea_MAXLEFT;

bool m_isPushedFlagU;				// 上方向キー
bool m_isPushedFlagD;				// 下方向キー
bool m_isPushedFlagR;				// 右方向キー
bool m_isPushedFlagL;				// 左方向キー
bool m_isPushedFlagZ;				// Zキー
bool m_isPushedFlagX;				// Xキー
bool m_isPushedFlagC;				// Cキー
bool m_isPushedFlagC2;				// Cキー押し込み確認フラグ２
bool m_isPushedFlagS;				// スペースキー
bool m_isPushedFlagA;
bool pushOkFlag;

bool wallStickRight;
bool wallStickLeft;

int whereStandGround;					// どこに着地しているかを示す

int m_doubleKeyDashR;				// ダブルキーダッシュ処理のフラグ右
int m_doubleKeyDashL;				// ダブルキーダッシュ処理のフラグ左
bool doubleSucsess;					// ダブルキーダッシュ成功フラグ

bool aerialFlag;					// 空中フラグ
bool doubleLandFlag;				// 二重着地防止フラグ
bool doubleLandFlag2;
bool doubleDashFlag;				// 多重ダッシュ禁止フラグ
bool doubleChargeFlag;				// 多重チャージ禁止フラグ
bool doubleJumpFlag;				// 多重ジャンプフラグ
bool fadeInFlag;
bool textFlag;

bool jumpFlag;						// ジャンプフラグ
int g_jumpHoldCounter;				// ジャンプ値変数
int g_dashHoldCounter;				// ダッシュ値変数
int g_chargeHoldCounter;			// チャージ値変数

// スクロール速度変数
float m_scroll_X;
float m_scroll2_X;
float m_scroll3_X;


// 画面領域を指定する
RECT g_screenArea{0, 720, 960, 0};	// 画面動作領域



//=============================================================================
//
//	*****   ここから変更禁止   *****
//
//=============================================================================

GameMain::GameMain():
// 静流FIX 2014-0819
m_windowConsole(0)
{
	gGameMain = this;
};

GameMain::~GameMain()
{
	this->endGame() ;
}

//=============================================================================
//	createScene
//		シーンの作成
//	-----------------------------------------------------------------------
//	OUTPUT:		Scene*			取り付けようのシーンクラス
//	-----------------------------------------------------------------------
//	TIPS:		この部分は残しておくが解り易くする為に AppDelegate の方には
//				直でシーンの生成からを実装しておく
//=============================================================================
Scene* GameMain::createScene()
{
    // シーンの生成
    Scene* scene = Scene::create();
    
    // レイヤーの生成
    GameMain* layer = new GameMain();
	
    // レイヤーをシーンに取り付ける
    scene->addChild(layer);
	
    // 生成したシーンを返す
    return scene ;
}

//=============================================================================
//	onKeyPressed
//		キーボードを押した際のイベント
//	TIPS:		変更禁止
//	-----------------------------------------------------------------------
//	INPUT:		KeyCode			キーコード
//				Event			イベント
//	OUTPUT:		void
//=============================================================================
void GameMain::onKeyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event)
{
	InputManager::getInstance()->onKeyPressed( keyCode ) ;
}

//=============================================================================
//	onKeyReleased
//		キーボードを話した際のイベント
//	TIPS:		変更禁止
//	-----------------------------------------------------------------------
//	INPUT:	KeyCode			キーコード
//			Event			イベント
//	OUTPUT:	void
//=============================================================================
void GameMain::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* unused_event)
{
	InputManager::getInstance()->onKeyReleased( keyCode ) ;
}

//=============================================================================
//	init
//		初期化処理
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
bool GameMain::init()
{
	// 親レイヤーの初期化
	if ( Layer::init() == false )
	{
		return false ;
	}

	// キーボード入力イベント受け取り設定
	this->setKeyboardEnabled(true) ;
	
	// 更新処理の設定
	this->scheduleUpdate();
	
	// 開始処理
	if ( this->initGame() == false )
	{
		return false ;
	}
	
	return true ;
}

//=============================================================================
//	update
//		更新処理
//	-----------------------------------------------------------------------
//	INPUT:	float delta		経過時間
//	OUTPUT:	void
//=============================================================================
void GameMain::update(float deltaTime)
{
	if ( IsKeyPressed( KEY_FLAG::ESCAPE ) == true )
	{
		exit(0) ;
	}
	
	this->inputAll() ;
	this->updateAll( deltaTime ) ;
	this->drawAll() ;
}

//=============================================================================
//	createSprite
//		スプライトの作成
//	-----------------------------------------------------------------------
//	INPUT:	TEXTURE* pTex					テクスチャ
//			cocos2d::Sprite*& pSprite		スプライト
//	OUTPUT:	void
//=============================================================================
void GameMain::createSprite( TEXTURE* pTex, cocos2d::Sprite*& pSprite )
{
	pSprite = Sprite::createWithTexture( pTex->m_pTexture );
}

//=============================================================================
//	addToScreen
//		スプライトをスクリーンに追加
//	-----------------------------------------------------------------------
//	INPUT:	cocos2d::Sprite* pSprite		スプライト
//	OUTPUT:	void
//=============================================================================
void GameMain::addToScreen( cocos2d::Sprite* pSprite )
{
	this->addChild( pSprite ) ;
}

//=============================================================================
//	removeFromScreen
//		スプライトをスクリーンから取り外す
//	-----------------------------------------------------------------------
//	INPUT:	cocos2d::Sprite* pSprite		スプライト
//	OUTPUT:	void
//=============================================================================
void GameMain::removeFromScreen( cocos2d::Sprite* pSprite )
{
    pSprite->removeFromParent() ;
}
//=============================================================================
//
//	*****   ここまで変更禁止   *****
//
//=============================================================================








////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//=============================================================================
//	initGame
//		ゲーム開始処理
//	-----------------------------------------------------------------------
//	OUTPUT:	bool		 true...成功
//						false...失敗
//=============================================================================
bool GameMain::initGame()
{
	
	// 入力処理の入力を初期化
	// InputManager::getInstance()->clear();
	
	
	// ゲームモードを最初はストップにして「READY？」を表示させる
	m_gameMode = kGameMode::kGameMode_NORMAL;
	
	scroolFlagRight = false;
	scroolFlagLeft = false;
	
	ifBlockStandFlag = false;
	isInArea_MAXLEFT = false;
	
	m_startCount = 60;
	m_startCount2 = -2;			// -2を入れればディレイが発動する（ステージによって切り替えたほうがいいかも）
	readySeFlag = 0;
	//m_windowScale = 0.0f;
	fadeInFlag = false;
	textFlag = false;
	m_sb_rotation = 0;
	g_sBNumber = 0;
	g_intersect_RIGHT = false;
	g_intersect_LEFT = false;
	
	wallStickRight = false;
	
	// 重複入力防止キーフラグの初期化
	m_isPushedFlagU = false;
	m_isPushedFlagD = false;
	m_isPushedFlagR = false;
	m_isPushedFlagL = false;
	m_isPushedFlagZ = false;
	m_isPushedFlagX = false;
	m_isPushedFlagC = false;
	m_isPushedFlagC2 = false;
	m_isPushedFlagS = false;
	
    // 楽曲を予め読み込んでおく
    SimpleAudioEngine::getInstance()->preloadBackgroundMusic("openingStage.mp3");   // 楽曲読み込み
	
	// ゲーム開始時に音再生
    SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0.2);				// BGM音量調整
	SimpleAudioEngine::getInstance()->playBackgroundMusic("OpeningStage.mp3", true);// BGM再生
	
	// プリロード
	SimpleAudioEngine::getInstance()->preloadEffect("fa2.wav");						// ふぉーすあろー(小)効果音
	SimpleAudioEngine::getInstance()->preloadEffect("jump.wav");					// ジャンプ効果音
	SimpleAudioEngine::getInstance()->preloadEffect("dash3.wav");					// ダッシュ効果音
	SimpleAudioEngine::getInstance()->preloadEffect("land.wav");					// 着地効果音
	SimpleAudioEngine::getInstance()->preloadEffect("charge2.wav");					// チャージ効果音
	SimpleAudioEngine::getInstance()->preloadEffect("chargeComp.wav");				// チャージ完了効果音
	SimpleAudioEngine::getInstance()->preloadEffect("LJump.wav");					// ルナボイス ジャンプ
	SimpleAudioEngine::getInstance()->preloadEffect("LDash.wav");					// ルナボイス ダッシュ
	SimpleAudioEngine::getInstance()->preloadEffect("ready3.wav");					// ルナボイス ステージ開始
	SimpleAudioEngine::getInstance()->preloadEffect("ready.mp3");					// ステージ開始時の ﾋﾟｭｰﾝ 音
	SimpleAudioEngine::getInstance()->preloadEffect("pause.wav");					// ルナボイス ポーズ
	SimpleAudioEngine::getInstance()->preloadEffect("middle_fa3.wav");				// ふぉーすあろー中の発射音
	SimpleAudioEngine::getInstance()->preloadEffect("message3.wav");
	

	// 効果音のボリュームを指定
    SimpleAudioEngine::getInstance()->setEffectsVolume(0.3);						// すべてのSEの音量調整をここで行う
	
	// 重力
	gravity = -9.8f;						// 重力の初期化
	g_checkStandGround = 0;					// 接地フラグをオン
	jumpFlag = false;						// ジャンプフラグはオフ
	charge = 0;								// サウンドIDを念のため初期化
	
	jump_power = 35;						// ジャンプ力を初期化子て定数化しておく
	
	// 各背景の初期位置をここで初期化
	m_scroll_X = 480.0f;
	m_scroll2_X = 480.0f+960.0f;
	m_scroll3_X = -480.0f;
	
	// 多重処理防止のフラグの初期化
	doubleLandFlag = false;
	doubleLandFlag2 = false;
	
	doubleDashFlag = false;
	doubleChargeFlag = false;
	doubleJumpFlag = false;
		
	dashFlag = false;						// ダッシュフラグはオフに
	g_dashHoldCounter = 0;					// ダッシュ値を０に
	g_chargeHoldCounter = 0;				// チャージ値を０に
	
	
	// 背景画像の初期化
    if (FAILED(loadImage("openingBg.jpeg", &g_bgTexture)) == true){
		CCLOG("背景画像がありません\n");
		return false;
	}
	// 背景中央
	this->createSprite(&g_bgTexture, g_pBg);
	this->addToScreen(g_pBg);
	g_pBg->setPosition(m_scroll_X, 360.0f);

	// 背景 右
	this->createSprite(&g_bgTexture, g_pBg2);
	this->addToScreen(g_pBg2);
	g_pBg2->setPosition(m_scroll2_X, 360.0f);
	
	// 背景 左
	this->createSprite(&g_bgTexture, g_pBg3);
	this->addToScreen(g_pBg3);
	g_pBg3->setPosition(m_scroll3_X, 360.0f);
	
	
	
	// 地面画像の初期化
	if (FAILED(loadImage("ground.png", &g_groundTexture)) == true){
		CCLOG("地面画像がありません\n");
		return false;
	}
	this->createSprite(&g_groundTexture, g_pGround.m_sprite);
	this->addToScreen(g_pGround.m_sprite);
	g_pGround.m_sprite->setZOrder(1);
	setChip(&g_pGround.m_chip, 0, 0, 960, 64, 480, 32);
	g_pGround.m_move.setMovePos(480, 32);
	setRect(&g_pGround.m_body, 0, 0, 960, 64);
	g_pGround.m_activeFlag = true;

	
	// UI画像の初期化
	if (FAILED(loadImage("UI.png", &g_uiTexture)) == true)
	{
		CCLOG("UI画像がありません\n");
		return false;
	}
	// UIスプライトを生成
	this->createSprite(&g_uiTexture, g_ui);
	this->addToScreen(g_ui);

	
	// ブロック画像の初期化
	if (FAILED(loadImage("block.jpg", &g_blockTexture)) == true){
		CCLOG("ブロック画像がありません\n");
		return false;
	}
	
	// テクスチャからスプライトを生成
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		this->createSprite(&g_blockTexture, g_block[i].m_sprite);
		this->addToScreen(g_block[i].m_sprite);
		
		// 初期位置を決める
		g_block[i].m_move.setMovePos(480+(i*128), 64);

		// チップの範囲を決める
		setChip(&g_block[i].m_chip, 0, 0, 128, 256, 64, 128);
		// ブロックの実体を決める
		setRect(&g_block[i].m_body, 0, 0, 128, 256);
		// ブロックのアクティブフラグをオン
		//g_block[i].m_activeFlag = true;
		
		g_block[i].m_activeFlag = false;
		g_block[i].m_sprite->setVisible(false);
	}
	
	// メニュー画像の初期化
	if (FAILED(loadImage("menu.png", &g_menuTexture)) == true)
	{
		CCLOG("メニュー画像がありません\n");
		return false;
	}
	this->createSprite(&g_menuTexture, g_pMenu);
	this->addToScreen(g_pMenu);
	
	// 初期状態はメニュー画面が見えない
	g_pMenu->setVisible(false);
	g_pMenu->setZOrder(10); // 描画レイヤーを一番手前にしておく
	
	
	
	// ルナ画像の初期化
	if (FAILED(loadImage("ChrChip2.png", &g_lunaTexture)) == true)
	{
		CCLOG("ルナ画像がありません\n");
		return false;
	}
	this->createSprite(&g_lunaTexture, m_luna.m_sprite);
	this->addToScreen(m_luna.m_sprite);
	
	// ルナのチップを設定
	setChip(&m_luna.m_chip, 0, 0, 64, 128, 32, 64);
	
	// ルナの初期位置を設定
	m_luna.m_move.setMovePos(-64.0f, 127.0f);
	
	// ルナの透過度を指定
	g_lunaOpacity = 255;
	
	// ふぉーすあろー発射間隔の調整
	g_forceArrowIntervalTime = 0;
	m_luna.m_shotCounter = g_forceArrowIntervalTime;
	
	// ショットアニメーションのカウント
	g_shotAnimationTime = 0;
	
	// アニメーションの速度の初期化
	g_animationSpeed = 3;
	
	// ジャンプ値を０にしておく
	g_jumpHoldCounter = 0;
	
	// ジャンプ頂点フラグを下ろす
	g_jumpTopFlag = false;
	
	// ふぉーすあろーが発射されている初期値は０；
	g_forceArrowNumber = 0;
	
	// ダブルキーカウント関連を初期化
	m_doubleKeyDashR = 0;
	m_doubleKeyDashL = 0;
	doubleSucsess = false;
	
	// ルナのアクティブフラグをオンにしておく
	m_luna.m_activeFlag = true;
	m_luna.m_sprite->setVisible(true);
	
	// ルナの方向ベクトルYは０
	m_luna.m_move.m_velX = 0.0f;
	m_luna.m_move.m_velY = 0.0f;
	m_luna.m_move.m_accY = 0.02f;
	
	// アニメーションと向きの初期化
	m_LunaMuki = kLunaMuki::RIGHT;
	m_lunaAnimation = kLunaAnimation::WALK_RIGHT;
	
	
	// ステージ開始テクスチャの読み込み
	if (FAILED(loadImage("ready.png", &g_readyTexture)) == true){
		CCLOG("レディー？画像がありません\n");
		return false;
	}
	this->createSprite(&g_readyTexture, g_r.m_sprite);
	this->addToScreen(g_r.m_sprite);
	// Rのチップを設定
	setChip(&g_r.m_chip, 0, 0, 128, 128, 64, 64);
	
	this->createSprite(&g_readyTexture, g_e.m_sprite);
	this->addToScreen(g_e.m_sprite);
	// Eのチップを設定
	setChip(&g_e.m_chip, 128, 0, 128, 128, 64, 64);
	
	this->createSprite(&g_readyTexture, g_a.m_sprite);
	this->addToScreen(g_a.m_sprite);
	// Aのチップを設定
	setChip(&g_a.m_chip, 256, 0, 128, 128, 64, 64);
	
	this->createSprite(&g_readyTexture, g_d.m_sprite);
	this->addToScreen(g_d.m_sprite);
	// Dのチップを設定
	setChip(&g_d.m_chip, 256+128, 0, 128, 128, 64, 64);
	
	this->createSprite(&g_readyTexture, g_y.m_sprite);
	this->addToScreen(g_y.m_sprite);
	// Yのチップを設定
	setChip(&g_y.m_chip, 512, 0, 128, 128, 64, 64);
	
	// それぞれ開始位置を指定しておく
	g_r.m_move.setMovePos(480.0f-256.0f, 1000.0f);
	g_e.m_move.setMovePos(480.0f-128.0f, 1000.0f);
	g_a.m_move.setMovePos(480.0f,		 1000.0f);
	g_d.m_move.setMovePos(480.0f+128.0f, 1000.0f);
	g_y.m_move.setMovePos(480.0f+256.0f, 1000.0f);
	

	
	
	
	// ふぉーす あろー画像の初期化
	if (FAILED(loadImage("bullet.png", &g_fATexture)) == true){
		CCLOG("ふぉーすあろー画像がありません\n");
		return false;
	}
	for (int i = 0; i < MAX_BULLET ; i++) {
		
		g_forceArrow[i].m_activeFlag = false;
		
		this->createSprite(&g_fATexture, g_forceArrow[i].m_sprite);
		this->addToScreen(g_forceArrow[i].m_sprite);
		
		g_forceArrow[i].m_sprite->setVisible( false );
	}
	
	// しゅーてぃんぐ ぶれいず画像の初期化
	if (FAILED(loadImage("shootingBlaze.png", &g_sBTexture)) == true){
		CCLOG("しゅーてぃんぐ ぶれいず画像がありません\n");
		return false;
	}
	for (int i = 0; i < MAX_SBLAZE ; i++)
	{
		g_shootingBlaze[i].m_activeFlag = false;
		
		this->createSprite(&g_sBTexture, g_shootingBlaze[i].m_sprite);
		this->addToScreen(g_shootingBlaze[i].m_sprite);
		g_shootingBlaze[i].m_sprite->setRotation( m_sb_rotation);
		g_shootingBlaze[i].m_sprite->setVisible( false );
	}


	// 砂埃画像の初期化
	if (FAILED(loadImage("smoke.png", &g_smokeTexture)) == true)
	{
		CCLOG("砂埃画像がありません\n");
		return false;
	}
	
	for (int i = 0; i < MAX_SMOKE ; i++)
	{
		g_smoke[i].m_activeFlag = false;
		
		this->createSprite(&g_smokeTexture, g_smoke[i].m_sprite);
		this->addToScreen(g_smoke[i].m_sprite);
		
		g_smoke[i].m_sprite->setVisible( false );
	}
	
	// ルナの実体画像の初期化
	if (FAILED(loadImage("lunaBody.png", &g_lunaBodyTexture)) == true)
	{
		CCLOG("ルナ実体画像がありません\n");
		return false;
	}
	
	// 衝突判定　左側
	this->createSprite(&g_lunaBodyTexture, g_lunaBody[BODY_LEFT].m_sprite);
	this->addToScreen(g_lunaBody[BODY_LEFT].m_sprite);
	
	// 衝突判定　右側
	this->createSprite(&g_lunaBodyTexture, g_lunaBody[BODY_RIGHT].m_sprite);
	this->addToScreen(g_lunaBody[BODY_RIGHT].m_sprite);
	
	// 衝突判定　上側
	this->createSprite(&g_lunaBodyTexture, g_lunaBody[BODY_UP].m_sprite);
	this->addToScreen(g_lunaBody[BODY_UP].m_sprite);
	
	// 衝突判定　下側
	this->createSprite(&g_lunaBodyTexture, g_lunaBody[BODY_BOTTOM].m_sprite);
	this->addToScreen(g_lunaBody[BODY_BOTTOM].m_sprite);
	
	// 衝突判定　中央側
	this->createSprite(&g_lunaBodyTexture, g_lunaBody[BODY_CENTER].m_sprite);
	this->addToScreen(g_lunaBody[BODY_CENTER].m_sprite);
	
	// ルナの実体のそれぞれのスプライトの上下左右の範囲を決める
	setChip(&g_lunaBody[BODY_LEFT].m_chip, 0, 6, 2, 116, 1, 58);
	setChip(&g_lunaBody[BODY_RIGHT].m_chip, 62, 6, 2, 116, 1, 58);
	setChip(&g_lunaBody[BODY_UP].m_chip, 6, 0, 52, 2, 26, 1);
	setChip(&g_lunaBody[BODY_BOTTOM].m_chip, 6, 126, 52, 2, 26, 1);
	setChip(&g_lunaBody[BODY_CENTER].m_chip, 2, 2, 60, 124, 30, 62);
	
	// こっちが初期位置
	g_lunaBody[BODY_LEFT].m_move.setMovePos(m_luna.m_move.m_posX - 32, m_luna.m_move.m_posY);
	g_lunaBody[BODY_RIGHT].m_move.setMovePos(m_luna.m_move.m_posX + 32, m_luna.m_move.m_posY);
	g_lunaBody[BODY_UP].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 64);
	g_lunaBody[BODY_BOTTOM].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 64);
	g_lunaBody[BODY_CENTER].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	
	
	for (int i = 0; i < LUNA_BODY; i++)
	{
		g_lunaBody[i].m_activeFlag = m_luna.m_activeFlag;
		g_lunaBody[i].m_sprite->setOpacity(255);
		g_lunaBody[i].m_sprite->setVisible(m_luna.m_activeFlag);
	}

	g_lunaBody[BODY_CENTER].m_sprite->setOpacity(0);
	
	setRect(&g_lunaBody[BODY_LEFT].m_body,0, 0, 2, 116);
	setRect(&g_lunaBody[BODY_RIGHT].m_body,0, 0, 2, 116);
	setRect(&g_lunaBody[BODY_UP].m_body,0, 0, 52, 2);
	setRect(&g_lunaBody[BODY_BOTTOM].m_body,0, 0, 52, 2);
	setRect(&g_lunaBody[BODY_CENTER].m_body,0, 0, 60, 124);
	
	
	// デバッグ用のテキストを表示させておく
	this->debug();
	
	
    // 静流FIX 2014-0819
    m_windowConsole = new WindowConsole;
    m_windowConsole ->nextLabel("文字送り、動作テストなのっ！嬲二行目嬲三行目嬲土井嬲北川");
	
	return true ;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//=============================================================================
//	endGame
//		ゲーム終了処理
//	-------------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::endGame()
{
	// 背景画像の終了処理
	this->removeFromScreen(g_pBg);
	this->removeFromScreen(g_pBg2);
	this->removeFromScreen(g_pBg3);
	releaseTexture(&g_bgTexture);
	
	// 地面画像の終了処理
	this->removeFromScreen(g_pGround.m_sprite);
	releaseTexture(&g_groundTexture);
	
	
	for(int i = 0; i < MAX_BLOCK; i++)
	{
		this->removeFromScreen(g_block[i].m_sprite);
		releaseTexture(&g_blockTexture);
	}
	
	// UI画像の終了処理
	this->removeFromScreen(g_ui);
	releaseTexture(&g_uiTexture);
	
	// ルナ画像の終了処理
	this->removeFromScreen(m_luna.m_sprite);
	releaseTexture(&g_lunaTexture);
	
	// 出撃処理用のテクスチャとスプライトを解放
	this->removeFromScreen(g_r.m_sprite);
	this->removeFromScreen(g_e.m_sprite);
	this->removeFromScreen(g_a.m_sprite);
	this->removeFromScreen(g_d.m_sprite);
	this->removeFromScreen(g_y.m_sprite);
	
	releaseTexture(&g_readyTexture);
	
	
	// ふぉーすあろーの終了処理
	for (int i = 0;  i < MAX_BULLET; i++)
	{
		this->removeFromScreen(g_forceArrow[i].m_sprite);
	}
	// テクスチャの解放
	releaseTexture(&g_fATexture);
	
	// しゅーてぃんぐ ぶれいずの終了処理
	for (int i = 0;  i < MAX_SBLAZE; i++)
	{
		this->removeFromScreen(g_shootingBlaze[i].m_sprite);
	}
	// テクスチャの解放
	releaseTexture(&g_sBTexture);
	
	// 砂埃の終了処理
	for (int i = 0;  i < MAX_SMOKE; i++)
	{
		this->removeFromScreen(g_smoke[i].m_sprite);
	}
	// テクスチャの解放
	releaseTexture(&g_smokeTexture);
	
	
	// 実体の終了処理
	for (int i = 0;  i < LUNA_BODY; i++)
	{
		this->removeFromScreen(g_lunaBody[i].m_sprite);
	}
	// テクスチャの解放
	releaseTexture(&g_lunaBodyTexture);
	
	// メニュー画面の取り外し
	this->removeFromScreen(g_pMenu);
	releaseTexture(&g_menuTexture);
    
    delete m_windowConsole;
    m_windowConsole = 0;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//=============================================================================
//	inputAll
//		キー入力に伴う変数の更新処理を行う
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::inputAll()
{
	
	// ルナが被弾している時や死んだ時はキー入力を受け付けない
	if (m_luna.m_activeFlag == false )
	{
		return;
	}
	

	switch (m_gameMode)
	{
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			// ストップのときの入力処理
		case kGameMode::kGameMode_STOP:
			
			// 何も取得しない
			
			break;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			// イベントのときの入力処理
		case kGameMode::kGameMode_EVENT:
			/*
			//
			// セリフが表示されてる時にボタン押したらセリフが更新されます
			//
			if(IsKeyPressed(KEY_FLAG::Z_KEY) && pushOkFlag == true)
			{
				
				if (m_isPushedFlagZ == false )
				{
					m_isPushedFlagZ = true;
					
					// テキストコントロールに数値をインクリメントしてウィンドウを更新する
					//textControl += 1;
					
					//if(textControl <= 11)
						// this->textUpdate();
					else
					{
						SimpleAudioEngine::getInstance()->playEffect("windowB.mp3",false);
						textWindowName->removeFromParentAndCleanup(true);
						textWindowMessage->removeFromParentAndCleanup(true);
					}
					
				}
			}
			else if(IsKeyPressed(KEY_FLAG::Z_KEY) == false && pushOkFlag == true)
			{
				// Zキーを放したらフラグをオフに戻すよ〜・ｗ・
				if ( m_isPushedFlagZ == true )
				{
					// false にまた戻すの〜・ｗ・
					m_isPushedFlagZ = false;
				}
			}

			
			if(IsKeyPressed(KEY_FLAG::C_KEY) && pushOkFlag == true && m_isPushedFlagZ == false)
			{
				textControl = 12;
				SimpleAudioEngine::getInstance()->playEffect("windowB.mp3",false);
				textWindowName->removeFromParentAndCleanup(true);
				textWindowMessage->removeFromParentAndCleanup(true);
			}
			*/
			break;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
			// ゲームモード
		case kGameMode::kGameMode_NORMAL:
			
			
			// ノーマルモード中に
			// スペースボタンを押すと・・・ポーズ処理！・ｗ・
			if(IsKeyPressed(KEY_FLAG::SPACE))
			{
				// 連続入力防止〜！・ｗ・
				if (m_isPushedFlagS == false )
				{
					m_isPushedFlagS = true;
					
					// ルナボイスを再生してゲームモードをポーズに変更！・ｗ・
					SimpleAudioEngine::getInstance()->stopAllEffects();
					SimpleAudioEngine::getInstance()->playEffect("pause.wav",false);
					m_gameMode = kGameMode_PAUSE;
					
					// ポーズ画像を表示設定に変更
					g_pMenu->setVisible( true );
					m_luna.m_sprite->setVisible( false );
					
				}
			}
			else
			{
				if ( m_isPushedFlagS == true )
				{
					// false にまた戻すの〜・ｗ・
					m_isPushedFlagS = false;
				}
			}
			
		
	//
	// 右キーの入力処理
	//
		
	if(IsKeyPressed(KEY_FLAG::RIGHT))
	{
		/*
		if( g_jumpHoldCounter == 21 && g_intersect_RIGHT && (jumpFlag || dashJumpFlag))
		{
			wallStickRight = true;
		}
		else if( g_checkStandGround != 0)
		{
			wallStickRight = false;
		}
		*/

		if(dashFlag == false)
			scroolFlagRight = true;
		
		if(g_checkStandGround == 0)
		m_LunaMuki = kLunaMuki::RIGHT;
		
		if (m_isPushedFlagR == false )
		{
			m_isPushedFlagR = true ;
			
			
			
			// ダブルキーダッシュ処理
			if (m_doubleKeyDashR > 0)
			{
				if(g_intersect_RIGHT == false)
				{
					doubleSucsess = true;
				}
			}
			
			// ダブルキーダッシュフラグが０ではないならば０に
			if (m_doubleKeyDashR != 0)
				m_doubleKeyDashR = 0;
			
			// ダブルキーダッシュカウントが０で、ダッシュフラグがオフなら
			if (m_doubleKeyDashR == 0 && dashFlag == false)
				m_doubleKeyDashR = 15;								// この数値にする
		}
		// 向きを右向きに変更
		if((g_checkStandGround > 0 && dashFlag == false) || (dashJumpFlag) )
			m_LunaMuki = kLunaMuki::RIGHT;
		// 歩行アニメーション右向きに変更
		
		if(g_intersect_RIGHT == false)
		{
			// ジャンプフラグが降りていれば
			if (jumpFlag == false && dashFlag==false)
			{
				// ルナのアニメーションを歩行に切り替える
				m_lunaAnimation = kLunaAnimation::WALK_RIGHT;
			}
		}
		// ダッシュジャンプフラグがオンならば
		if(dashJumpFlag)
		{
			// X成分の速度を変える
			if(g_intersect_RIGHT == false)
			{
				m_luna.m_move.m_velX = 18.0f;
				m_LunaMuki = kLunaMuki::RIGHT;
			}
		}
		else if(dashFlag == false)
		{
			if(g_intersect_RIGHT == false)
			{
				// 歩行速度
				m_luna.m_move.m_velX = 5.5f;
			}
		}
	}
	else
	{
		if (m_isPushedFlagR == true )
		{
			m_isPushedFlagR = false ;
			
			scroolFlagRight = false;
			
			if(IsKeyPressed(KEY_FLAG::LEFT) == false)
				m_luna.m_move.m_velX = 0.0f;
				
			// ダブルキーダッシュ成功フラグをオフにする。
			if(dashFlag)
				doubleSucsess = false;
			else
				m_luna.m_move.m_velX = 0.0f;
			
			if( g_intersect_RIGHT && jumpFlag && wallStickRight)
			{
				//wallStickRight = false;
			}
		}

	}
			
	
	//
	// 左キーの入力処理
	//
	if(IsKeyPressed(KEY_FLAG::LEFT))
	{
		if(dashFlag == false)
			scroolFlagLeft = true;
		
		if(g_checkStandGround == 0)
		m_LunaMuki = kLunaMuki::LEFT;
		
		if (m_isPushedFlagL == false )
		{
			m_isPushedFlagL = true ;
			
			
			
			// ダブルキーダッシュカウントが０より上の時にボタン入力に成功したら
			if (m_doubleKeyDashL > 0)
			{
				if(g_intersect_LEFT == false)
				{
				// ダッシュが成功します
				doubleSucsess = true;
				}
			}
			
			// ダブルキーダッシュが
			if (m_doubleKeyDashL != 0)
				m_doubleKeyDashL = 0;
			
			// ダブルキーダッシュカウントが０またはダッシュ中ではない時
			if (m_doubleKeyDashL == 0 && dashFlag == false)
				m_doubleKeyDashL = 15;
		}
		
		// 向きを左に変更
		if((g_checkStandGround > 0 && dashFlag == false) || (dashJumpFlag) )
		m_LunaMuki = kLunaMuki::LEFT;
		
		// 歩行アニメーション左向きに変更
		// ジャンプフラグが降りていれば
		if(g_intersect_LEFT == false)
		{
		if (jumpFlag == false && dashFlag==false)
		{
			m_lunaAnimation = kLunaAnimation::WALK_LEFT;
		}
		}
		
		// ダッシュジャンプ中ならば
		if(dashJumpFlag)
		{
			if(g_intersect_LEFT == false)
			{
			// X成分の移動速度を変更
			m_luna.m_move.m_velX = 18.0f;
			m_LunaMuki = kLunaMuki::LEFT;
			}
		}
		else if(dashFlag == false)
		{
			if(g_intersect_LEFT == false)
			{
			// 歩行速度
			m_luna.m_move.m_velX = 5.5f;
			}
		}
	}
	else
	{
		if (m_isPushedFlagL == true )
		{
			m_isPushedFlagL = false ;
			
			scroolFlagLeft = false;
			
			if(IsKeyPressed(KEY_FLAG::RIGHT) == false)
				m_luna.m_move.m_velX = 0.0f;
			
			// ダブルキーダッシュ成功フラグをオフに
			if(dashFlag)
				doubleSucsess = false;
			else
				m_luna.m_move.m_velX = 0.0f;
		}
		
	}
	
	
			//
			// しゅーてぃんぐぶれいず！！！
			//
			if (m_luna.m_shotCounter <= 0 && g_sBNumber < 1)
			{
				// Zキーが押されたら
				if(IsKeyPressed(KEY_FLAG::A_KEY))
				{
					// 連続入力防止〜！・ｗ・
					if (m_isPushedFlagA == false )
					{
						m_isPushedFlagA = true;
						// 射出アニメーションフレームカウンタを20に
						g_shotAnimationTime = 20;
						
						
						// ふぉーすあろー用のSEを再生
						SimpleAudioEngine::getInstance()->playEffect("shootingBlaze.wav",false);
						
						// ルナのアニメーションカウンタを元に戻す
						m_luna.m_animeCounter = 0;
						
						// ショットアニメーション処理
						if (m_LunaMuki == RIGHT)
						{
							// 右向き
							m_lunaAnimation = kLunaAnimation::SHOT_RIGHT;
							
						}
						else
						{
							// 左向き
							m_lunaAnimation = kLunaAnimation::SHOT_LEFT;
						}
						
						// ふぉーすあろー発射！・ｗ・
						this->Spell_shootingBlaze();
					}
				}
				else
				{
					// Zキーを放したらフラグをオフに戻すよ〜・ｗ・
					if ( m_isPushedFlagA == true )
					{
						// false にまた戻すの〜・ｗ・
						m_isPushedFlagA = false;

						m_sb_rotation = 0;
						
					}
				}
	
			}

			
			
			
			
			
			
			
			
			
			
	//
	// Zキーでふぉーすあろー射出
	//
	
	// ルナのふぉーすあろー総数が画面内に２つ以下である時、ショットインターバルカウンタが０以下の時
	if (m_luna.m_shotCounter <= 0 && g_forceArrowNumber <= 2)
	{
		// Zキーが押されたら
		if(IsKeyPressed(KEY_FLAG::Z_KEY))
		{
			// 連続入力防止〜！・ｗ・
			if (m_isPushedFlagZ == false )
			{
				m_isPushedFlagZ = true;
				// 射出アニメーションフレームカウンタを20に
				g_shotAnimationTime = 20;
				

				// ふぉーすあろー用のSEを再生
				SimpleAudioEngine::getInstance()->playEffect("fa2.wav",false);
				
				// ルナのアニメーションカウンタを元に戻す
				m_luna.m_animeCounter = 0;
				
				// ショットアニメーション処理
				if (m_LunaMuki == RIGHT)
				{
					// 右向き
					m_lunaAnimation = kLunaAnimation::SHOT_RIGHT;
				}
				else
				{
					// 左向き
					m_lunaAnimation = kLunaAnimation::SHOT_LEFT;
				}
				
				// ふぉーすあろー発射！・ｗ・
				this->shootMyBullet();
				
			}
			
			// ショットアニメーションが実行されていない時、チャージ値をインクリメント
			if((m_lunaAnimation!=kLunaAnimation::SHOT_RIGHT) || (m_lunaAnimation!=kLunaAnimation::SHOT_LEFT))
			{
				// ふぉーすあろーのチャージカウントをインクリメントしていく
				g_chargeHoldCounter++;
			}
			
			// チャージ値が[一定数]以上のとき１回のみ実行
			if(g_chargeHoldCounter >= 25 && doubleChargeFlag == false)
			{
				// サウンドIDを変数に格納する
				charge = SimpleAudioEngine::getInstance()->playEffect("charge2.wav",false);
				doubleChargeFlag = true;
			}
			// チャージ値が一定数を超えるとルナボイスが１回のみ実行される
			if (g_chargeHoldCounter == 70)
					SimpleAudioEngine::getInstance()->playEffect("chargeComp.wav",false);
			
			// チャージ中のルナの透過処理
			if(g_lunaOpacity > 0 && g_chargeHoldCounter >= 25)
			{
				// ルナをチャージ値にあわせて点滅させていく
				g_lunaOpacity -= 64 - (g_chargeHoldCounter*2);
			}
			else
			{
				// チャージ中でない場合は透過させない
				g_lunaOpacity = 255;
			}
		}
		else
		{
			// Zキーを放したらフラグをオフに戻すよ〜・ｗ・
			if ( m_isPushedFlagZ == true )
			{
				// false にまた戻すの〜・ｗ・
				m_isPushedFlagZ = false;
				
				// チャージ値が一定数を超えた状態でショットキーを放すと「はいぱーふぉーすあろー」を放つ
				if(g_chargeHoldCounter >= 25)
				{
					
					// チャージ値が２５以上の時、キーを放すとふぉーすあろーを発射
					this->shootMyBullet();
					
					// 射出アニメーションフレームカウンタを20に
					g_shotAnimationTime = 20;
					
					// ルナのアニメーションカウンタを元に戻す
					m_luna.m_animeCounter = 0;
					
					// ショットアニメーション処理
					if (m_LunaMuki == RIGHT)
					{
						// 右向き
						m_lunaAnimation = kLunaAnimation::SHOT_RIGHT;
					}
					else
					{
						// 左向き
						m_lunaAnimation = kLunaAnimation::SHOT_LEFT;
					}
			}
				
				// チャージ効果音を停止し、チャージカウンタを０にし、多重処理防止フラグを下ろす
				SimpleAudioEngine::getInstance()->stopEffect(charge);
				
				doubleChargeFlag = false;
				// キーを放すとチャージ値が０に戻る
				g_chargeHoldCounter = 0;
				// ここにも透過処理を戻すように書いておく
				g_lunaOpacity = 255;
				

			}
		}
	}
	else
	{
		// インターバルカウンタを減算
		m_luna.m_shotCounter--;
		// ここでもチャージ値をリセットする
		g_chargeHoldCounter = 0;
		
		// ここにもね・ｗ・
		g_lunaOpacity = 255;
		
	}
	
// ----------------------------------------------------------------------------------------------------------- //
		
	//
	// Xキーで高度調整が可能なジャンプ！
	//

	// ジャンプ値が８以下の時・Xキーが押されている時・ルナのアニメーションが壁蹴り開始を再生していない時
	
	// Xキーが押されたら
	if(IsKeyPressed(KEY_FLAG::X_KEY) )
	{
		

		
		// ２回めにここを通る時からジャンプ値をカウントしていくよ・ｗ・
		if (m_isPushedFlagX)
		{
			/*
			if(wallStickRight || wallStickLeft)
			{
				if(g_intersect_RIGHT)
				{
					m_luna.m_move.m_posY -= 10;
					// ここでインクリメントさせると内部フラグに影響があるため、これを除外する
					m_luna.m_move.m_velY = jump_power - g_jumpHoldCounter;
					doubleJumpFlag = true;
					
				}
				
				if(jumpFlag ||dashJumpFlag)
				g_jumpHoldCounter ++;
			}
			else*/
			{
				g_jumpHoldCounter ++;
			}
		}
			 
			
		// ダッシュジャンプ処理に移行したらダッシュ値を０にする
		if(dashJumpFlag)
			g_dashHoldCounter = 0;
		
		// 着地判定がオンの時
		if(g_checkStandGround > 0)
		{
			// ジャンプ値が１６以上の時
			if(g_jumpHoldCounter <= 16)
			{
				
				// ジャンプフラグがオフの時
				if(jumpFlag == false)
				{
					// 多重ジャンプ防止フラグ
					if(doubleJumpFlag == false)
					{
						// アニメーションが壁蹴り開始ではない時
						if(m_lunaAnimation != kLunaAnimation::KICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_START_LEFT)
						{
							// ジャンプアニメーション処理
							// 右向きなら
							if (m_LunaMuki == RIGHT)
							{
								// 右向き用のジャンプアニメーションに
								// 壁蹴り開始・壁蹴り中・ジャンプ頂点・壁貼り付き開始・壁張り付き中でない時
								if ((m_lunaAnimation != kLunaAnimation::KICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_START_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::KICK_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::JUMP_TOP_RIGHT || m_lunaAnimation != kLunaAnimation::JUMP_TOP_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::WALLSTICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_START_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::WALLSTICK_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_LEFT))
								{
									m_lunaAnimation = kLunaAnimation::JUMP_RIGHT;
								}
						
							}else if(m_LunaMuki == LEFT)
							{
								// 左向き用のアニメーションに
								// 壁蹴り開始・壁蹴り中・ジャンプ頂点・壁貼り付き開始・壁張り付き中でない時
								if ((m_lunaAnimation != kLunaAnimation::KICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_START_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::KICK_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::JUMP_TOP_RIGHT || m_lunaAnimation != kLunaAnimation::JUMP_TOP_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::WALLSTICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_START_LEFT) &&
									(m_lunaAnimation != kLunaAnimation::WALLSTICK_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_LEFT) )
								{
										m_lunaAnimation = kLunaAnimation::JUMP_LEFT;
								}
							}
						
							// ここは一度しか通らない・ｗ・
							if (m_isPushedFlagX == false )
							{
								// 強制的にルナのアニメーションカウンタを０に
								m_luna.m_animeCounter = 0;
								
								// 入力確認フラグをオンに
								m_isPushedFlagX = true;
								
								m_isPushedFlagC = true;
								
								// 効果音挿入部分
								SimpleAudioEngine::getInstance()->playEffect("jump.wav",false);
								SimpleAudioEngine::getInstance()->playEffect("LJump.wav",false);
								
								// ジャンプフラグをオン
								jumpFlag = true;
								
								// 多重接地処理防止フラグ
								if(g_checkStandGround == 1)
									doubleLandFlag = true;
								else if(g_checkStandGround == 2)
									doubleLandFlag2 = true;
							}
							
							// ジャンプ値をインクリメント
							if (g_jumpHoldCounter <= 16)
							{
								/*
								if(wallStickRight || wallStickLeft)
								{
									g_jumpHoldCounter = 21;
									jump_power = 0;
									m_luna.m_move.m_velY = 0;
								}
								else*/
								{
									// ここでインクリメントさせると内部フラグに影響があるため、これを除外する
									m_luna.m_move.m_velY = jump_power - g_jumpHoldCounter;
									doubleJumpFlag = true;
								}

							}
							else if(g_jumpHoldCounter == 21)	// ジャンプ値が最大の場合はそれ以上ジャンプ値が上昇しないようにしてY成分の速度とジャンプ力を０にする
							{
								g_jumpHoldCounter = 21;
								jump_power = 0;
								m_luna.m_move.m_velY = 0;
							}
						}
					}
				}
			}
		}
	}
	// Xキーが押されていない時の処理
	else if(IsKeyPressed(KEY_FLAG::X_KEY) == false )
	{
		// Xキーを放した時・ルナがジャンプ中の時・一度だけ実行
		if(m_isPushedFlagX && g_jumpHoldCounter <= 16
		   && (m_lunaAnimation != JUMP_RIGHT || m_lunaAnimation != JUMP_LEFT))
		{
			g_jumpHoldCounter = 21;
			m_isPushedFlagX = false;
		}
		
		// 多重ジャンプ処理を省く
		if(doubleJumpFlag == true)
		{
			doubleJumpFlag = false;
		}
		
	}
	
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

 
	//
	// Cキーでダッシュ処理
	//
	
		if(g_intersect_RIGHT == true || g_intersect_LEFT == true )
		{
			return;
		}
			
			
		// 地面に立っている・ジャンプしていない時・Zキーが押されたら
		if(IsKeyPressed(KEY_FLAG::C_KEY)== true || doubleSucsess)
		{

			//
			// ダッシュジャンプ処理
			//

			/*
			if(m_LunaMuki == RIGHT)
				scroolFlagRight = true;
			else
				scroolFlagLeft = true;
			*/
			
			// 地面に立っている時にダッシュキーが押されたら！
			if(g_checkStandGround > 0 )
			{

				// ダッシュが再生されるとダブルキーダッシュ処理を無効化するのよ・ｗ・
				m_doubleKeyDashR =0;
				m_doubleKeyDashL =0;
				
				// ダッシュ値が０以上・ジャンプ中・Cキーが再度押された時
				if (g_dashHoldCounter >= 1 && jumpFlag  && m_isPushedFlagC2 == false )
				{
					// ダッシュジャンプフラグをオンに・ｗ・
					m_isPushedFlagC2 = true;
					dashJumpFlag=true;
				}
				
				
				// 連続入力防止〜！・ｗ・
				if (m_isPushedFlagC == false )
				{
					m_isPushedFlagC = true;
					
					// ルナのアニメカウンターを０にしておく
					m_luna.m_animeCounter = 0;
					// ダッシュ効果音を再生
					SimpleAudioEngine::getInstance()->playEffect("dash3.wav",false);
					//SimpleAudioEngine::getInstance()->playEffect("LDash.wav",false);
					
					if(g_checkStandGround == 1)
						doubleLandFlag = true;
					else if(g_checkStandGround == 2)
						doubleLandFlag2 = true;
					
					// ダッシュカウンターをオンに
					dashFlag = true;
					
					if (dashFlag == true &&
						jumpFlag == false &&
						m_LunaMuki == RIGHT)
					{
						//アニメーションをダッシュに変更、ダッシュ値をインクリメント、移動処理を加える
						m_lunaAnimation = kLunaAnimation::JUMP_RIGHT;
						//g_dashHoldCounter = 0;
					}
					
					// 左方向のダッシュジャンプ
					else if (dashFlag == true &&
						jumpFlag == false &&
						m_LunaMuki == LEFT)
					{
						//アニメーションをダッシュに変更、ダッシュ値をインクリメント、移動処理を加える
						m_lunaAnimation = kLunaAnimation::JUMP_LEFT;
						//g_dashHoldCounter = 0;
					}
					
				}
				
				// ダッシュ中にジャンプがオンになった時！
				if(jumpFlag == false )
				{
					//if(fallFlag != true ){
						// 追加 右と左の壁と接触していない時
	
					// 右方向のルナのダッシュ処理
					// ダッシュフラグがオンで、ダッシュ値が３５ではない時
					if (dashFlag == true &&
						jumpFlag == false &&
						g_dashHoldCounter != 35 &&
						m_LunaMuki == RIGHT)
					{
						//アニメーションをダッシュに変更、ダッシュ値をインクリメント、移動処理を加える
						m_lunaAnimation = kLunaAnimation::DASH_RIGHT;
						g_dashHoldCounter++;
						m_luna.m_move.m_velX = 18.0f;
						scroolFlagRight = true;

						
					}
					
					// 左方向のルナのダッシュ処理
					// ダッシュフラグがオンで、ダッシュ値が３５ではない時
					if (dashFlag == true &&
						jumpFlag == false &&
						g_dashHoldCounter != 35 &&
						m_LunaMuki == LEFT)
					{
						//アニメーションをダッシュに変更、ダッシュ値をインクリメント、移動処理を加える
						m_lunaAnimation = kLunaAnimation::DASH_LEFT;
						g_dashHoldCounter++;
						m_luna.m_move.m_velX = 18.0f;
						scroolFlagLeft = true;

					}
				}

			}
		}
		
		else if (IsKeyPressed(KEY_FLAG::C_KEY)== false || doubleSucsess == false)
		{
			
			if(m_LunaMuki == RIGHT && !(IsKeyPressed(KEY_FLAG::RIGHT)))
				scroolFlagRight = false;
			else if(m_LunaMuki == LEFT && !IsKeyPressed(KEY_FLAG::LEFT))
				scroolFlagLeft = false;
			
			// Cキーを放したらフラグをオフに戻すよ〜・ｗ・
			if ( jumpFlag == false && m_isPushedFlagC == true )
			{
				// false にまた戻すの〜・ｗ・
				m_isPushedFlagC = false;
				
				dashFlag =false;

				if (m_LunaMuki == RIGHT)
				{
					// 右なら待機アニメーション右用
					m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
					scroolFlagRight = false;
				}
				else
				{
					// 左なら待機アニメーション左用
					m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
					scroolFlagLeft = false;
				}

			}
			// X成分の移動速度を０に戻しておく
			m_luna.m_move.m_velX += 0.0f;
			// ボタンを離した時、ダッシュフラグを下ろしてダッシュ値を０にする
			dashFlag = false;
			g_dashHoldCounter = 0;
			
		}
			
			break;
			
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
		// ポーズモード処理
		case kGameMode::kGameMode_PAUSE:
		{
		
			// ポーズモード中に
			// スペースボタンを押すと・・・！・ｗ・
			if(IsKeyPressed(KEY_FLAG::SPACE))
			{
				// 連続入力防止〜！・ｗ・
				if (m_isPushedFlagS == false )
				{
					m_isPushedFlagS = true;
					
					// ボリュームを元に戻す
					SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0.2);
					
					// モードをポーズに変更！・ｗ・
					m_gameMode = kGameMode_NORMAL;
					
					// ポーズ画像を表示設定に変更
					g_pMenu->setVisible( false );
					m_luna.m_sprite->setVisible( true );
				}
			}
			else
			{
				// Sキーを放したらフラグをオフに戻すよ〜・ｗ・
				if ( m_isPushedFlagS == true )
				{
					// false にまた戻すの〜・ｗ・
					m_isPushedFlagS = false;
				}
			}
			
		
			break;
		}
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
		default:
			break;
	}
			
	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//=============================================================================
//	updateAll
//		更新処理
//		移動・敵機出撃・衝突判定など、入力・描画以外の全ての処理を行う
//	-----------------------------------------------------------------------
//	INPUT:	float deltaTime		経過時間
//	OUTPUT:	void
//=============================================================================
void GameMain::updateAll( float deltaTime )
{
	// 追加
	if(IsKeyPressed(KEY_FLAG::X_KEY)){
		if(m_isPushedFlagX == false){
			m_windowConsole->nextLabel("文字送り〜・ｗ・");
			m_isPushedFlagX = true;
		}
	}
	else{
		if(m_isPushedFlagX == true){
			m_isPushedFlagX = false;
		}
	}
	m_windowConsole->update(deltaTime);
    
	switch (m_gameMode)
	{
		// ステージ開始直後
		case kGameMode::kGameMode_STOP:
			


			
			// ルナのアニメーションを再生
			this->lunaAnimation();
			
			// ステージ出撃処理中でも背景のスクロールはするよ・ｗ・
			if(m_scroll_X <= -480)
			{
				m_scroll_X = 0;
				m_scroll_X = 960+480;
			}
			if(m_scroll2_X <= -480)
			{
				m_scroll2_X = 0;
				m_scroll2_X = 480+960;
			}
			// スクロール処理
			//m_scroll_X -= 5.0f;
			//m_scroll2_X -= 5.0f;
			
			//
			// ここから出撃処理
			//
			// スタートカウントが０以上の時はずっとデクリメントする
			if(m_startCount > 0)
				m_startCount--;
			
			// スタートカウントが０になったらデクリメントを止めて変数に−１を入れておく
			if( m_startCount == 0)
			{
				m_startCount -=1;
			}

			// スタートカウント２に数値が代入されたらデクリメントしていく
			if(m_startCount2 > 0)
				m_startCount2--;
			
			// スタートカウント２が０になったら
			if( m_startCount2 == 0)
			{
				// レディー？　を再生してスタートカウント２を−１しておく
				SimpleAudioEngine::getInstance()->playEffect("ready3.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("kirara.mp3",false);
				m_startCount2 -=1;
			}
			
			// スタートカウントとスタートカウント２が両方共−１になった時に実行
			if( m_startCount == -1 && m_startCount2 == -1)
			{
				// ルナの位置が初期位置より左にいたら
				if(m_luna.m_move.m_posX < 256.0f)
				{
					// その位置まで動かして、アニメーションを変更する
					m_luna.m_move.m_posX += 4.5f;
					m_lunaAnimation = kLunaAnimation::WALK_RIGHT;
				}
				else
				{
					// ルナのX座標が初期位置より上になったら２５６にしてアニメーションを待機にする
					m_luna.m_move.m_posX = 256.0f;
					 m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
				}
				
				// ルナの位置が初期位置に到達したら
				if(m_luna.m_move.m_posX == 256.0f)
				{
					// 念のため、ルナの初期位置を再設定して
					// R E A D Y ? のチップの位置を動かしてやる・ｗ・
					m_luna.m_move.m_posX = 256.0f;
					g_r.m_move.m_posX -= 30;
					g_e.m_move.m_posX -= 30;
					g_a.m_move.m_posX -= 30;
					g_d.m_move.m_posX += 30;
					g_y.m_move.m_posX += 30;
					
					// R チップが -256 まで行ったらゲーム開始です
					if(g_a.m_move.m_posX <= -256)
					{
						// 効果音挿入 キラーン！
						//SimpleAudioEngine::getInstance()->playEffect("span.mp3",false);
						m_gameMode = kGameMode::kGameMode_EVENT;
					}
				}
				 
			}
			// R E A D Y チップの動き
			if(m_startCount == -1)
			{
				if (g_r.m_move.m_posY > 360){
					g_r.m_move.m_posY -= 40;
				}
				else if(g_r.m_move.m_posY <= 360)
				{
					if(readySeFlag == 0)
					{
						SimpleAudioEngine::getInstance()->playEffect("ready.mp3",false);
						readySeFlag = 1;
						g_r.m_move.m_posY = 360;
					}
					
					if (g_e.m_move.m_posY > 360)
					{
						g_e.m_move.m_posY -= 50;
					}
					else if(g_e.m_move.m_posY <= 360)
					{
						if(readySeFlag == 1)
						{
							SimpleAudioEngine::getInstance()->playEffect("ready.mp3",false);
							readySeFlag = 2;
							g_e.m_move.m_posY = 360;
						}
						
						if (g_a.m_move.m_posY > 360)
						{
							g_a.m_move.m_posY -= 50;
						}
						else if(g_a.m_move.m_posY <= 360)
						{
							if(readySeFlag == 2)
							{
								SimpleAudioEngine::getInstance()->playEffect("ready.mp3",false);
								readySeFlag = 3;
								g_a.m_move.m_posY = 360;
							}
							
							if (g_d.m_move.m_posY > 360)
							{
								g_d.m_move.m_posY -= 50;
							}
							else if(g_d.m_move.m_posY <= 360)
							{
								if(readySeFlag == 3)
								{
									SimpleAudioEngine::getInstance()->playEffect("ready.mp3",false);
									readySeFlag = 4;
									g_d.m_move.m_posY = 360;
								}
								
								if (g_y.m_move.m_posY > 360)
								{
									g_y.m_move.m_posY -= 50;
								}
								else if(g_y.m_move.m_posY <= 360)
								{
									if(readySeFlag == 4)
									{
										SimpleAudioEngine::getInstance()->playEffect("ready.mp3",false);
										readySeFlag = true;
										g_y.m_move.m_posY = 360;
										readySeFlag = -1;
										m_startCount2 = 30;
									}
								}
							}
						}
					}
				}

			}
			
			break;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			// イベントのときの入力処理
		case kGameMode::kGameMode_EVENT:
		{
			// ルナのアニメーションを再生
			this->lunaAnimation();
			
			// 立ち絵のアニメーションも再生
//			this->lunaFaceAnimation();
			
			
			// ステージ出撃処理中でも背景のスクロールはするよ・ｗ・
			if(m_scroll_X <= -480)
			{
				m_scroll_X = 0;
				m_scroll_X = 960+480;
			}
			if(m_scroll2_X <= -480)
			{
				m_scroll2_X = 0;
				m_scroll2_X = 480+960;
			}
			// スクロール処理
			//m_scroll_X -= 5.0f;
			//m_scroll2_X -= 5.0f;
			
			// イベントシーン独自のUIを見えるようにする
			//g_lunaMessageWindow->setVisible(true);
			//g_MessageName->setVisible(true);
			
			// ウィンドウのアニメーション
			//g_lunaMessageWindow->setScaleX(m_windowScale);
			//g_MessageName->setScaleX(m_windowScale);
			break;
		}
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			// ノーマルモード
		case kGameMode::kGameMode_NORMAL:

			// ここで状態の更新
			
			
			// 書く・ｗ・
			
			
			
			
			/*
			if(g_checkStandGround == 0)
			{
				if (dashFlag)
					dashFlag = false;
			}*/

			// 実体位置 と 実体範囲の更新
			if (dashFlag == true && jumpFlag == false)
			{
				g_lunaBody[0].m_move.setMovePos(m_luna.m_move.m_posX - 63, m_luna.m_move.m_posY);
				g_lunaBody[1].m_move.setMovePos(m_luna.m_move.m_posX + 63, m_luna.m_move.m_posY);
				g_lunaBody[2].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 31);
				g_lunaBody[3].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 31);
				g_lunaBody[4].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
				
				setRect(&g_lunaBody[BODY_LEFT].m_body,0, 0, 2, 52);
				setRect(&g_lunaBody[BODY_RIGHT].m_body,0, 0, 2, 52);
				setRect(&g_lunaBody[BODY_UP].m_body,0, 10, 42, 2);
				setRect(&g_lunaBody[BODY_BOTTOM].m_body,0, 10, 42, 2);
				setRect(&g_lunaBody[BODY_CENTER].m_body,0, 0, 60, 60);
			}
			else if(dashFlag == true && jumpFlag == true)
			{
				g_lunaBody[0].m_move.setMovePos(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
				g_lunaBody[1].m_move.setMovePos(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
				g_lunaBody[2].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
				g_lunaBody[3].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
				g_lunaBody[4].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
				
				setRect(&g_lunaBody[BODY_LEFT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_RIGHT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_UP].m_body,0, 10, 42, 2);
				setRect(&g_lunaBody[BODY_BOTTOM].m_body,0, 0, 42, 2);
				setRect(&g_lunaBody[BODY_CENTER].m_body,0, 0, 60, 124);
			}
			else if (dashFlag == false && jumpFlag == false)
			{
				g_lunaBody[0].m_move.setMovePos(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
				g_lunaBody[1].m_move.setMovePos(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
				g_lunaBody[2].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
				g_lunaBody[3].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
				g_lunaBody[4].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
				
				setRect(&g_lunaBody[BODY_LEFT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_RIGHT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_UP].m_body,0, 0, 52, 2);
				setRect(&g_lunaBody[BODY_BOTTOM].m_body,0, 0, 52, 2);
				setRect(&g_lunaBody[BODY_CENTER].m_body,0, 0, 60, 124);
			}
			else
			{
				g_lunaBody[0].m_move.setMovePos(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
				g_lunaBody[1].m_move.setMovePos(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
				g_lunaBody[2].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
				g_lunaBody[3].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
				g_lunaBody[4].m_move.setMovePos(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
				
				setRect(&g_lunaBody[BODY_LEFT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_RIGHT].m_body,0, 10, 2, 90);
				setRect(&g_lunaBody[BODY_UP].m_body,0, 0, 52, 2);
				setRect(&g_lunaBody[BODY_BOTTOM].m_body,0, 0, 52, 2);
				setRect(&g_lunaBody[BODY_CENTER].m_body,0, 0, 60, 124);
			}

			
			// 修正するかも
			for(int i = 0; i< MAX_SBLAZE; i++)
				g_shootingBlaze[i].m_sprite->setRotation( m_sb_rotation );
	
			// 砂煙をつけるのよ・ｗ・
			if(g_dashHoldCounter == 3 ||
			   g_dashHoldCounter == 8 ||
			   g_dashHoldCounter == 13 ||
			   g_dashHoldCounter == 18 ||
			   g_dashHoldCounter == 23 ||
			   g_dashHoldCounter == 28)
			{
				// ルナが立ってる・ジャンプ中ではない時に砂埃を出す
				if(g_checkStandGround > 0 && jumpFlag == false )
				{
					// ルナの向きによって砂埃の向きも決まる
					if(m_LunaMuki == RIGHT)
						this->smoke(&m_luna, g_smoke, MAX_SMOKE, -72, -16);
					else
						this->smoke(&m_luna, g_smoke, MAX_SMOKE, 72, -16);
				}
			}
			
			// 砂煙のアニメーション
			for (int i = 0; i < MAX_SMOKE; i++)
			{
					// アイテムチップの描画をX軸の数値だけ加算していく
					// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
					g_smoke[i].m_chip.m_texPos.x = 64 * (g_smoke[i].m_animeCounter / 2);
					
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					g_smoke[i].m_animeCounter++;
					
					// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
					if(g_smoke[i].m_animeCounter >= 8 * 2)
					{
						// 戻すの！・ｗ・
						g_smoke[i].m_animeCounter = 0;
						g_smoke[i].m_activeFlag = false;
						g_smoke[i].m_sprite->setVisible(false);
						
					}
			}
			
			// しゅーてぃんぐ ぶれいずのアニメーション
			for (int i = 0; i < MAX_SBLAZE; i++)
			{
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				g_shootingBlaze[i].m_chip.m_texPos.x = 192 * (g_shootingBlaze[i].m_animeCounter / 3);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				g_shootingBlaze[i].m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(g_shootingBlaze[i].m_animeCounter >= 4 * 3)
				{
					// 戻すの！・ｗ・
					g_shootingBlaze[i].m_animeCounter = 0;
				}

			}
			
			// ふぉーすあろーのアニメーション
			for (int i = 0; i < MAX_BULLET; i++)
			{
				if (g_forceArrow[i].m_type == 2)
				{

					// アイテムチップの描画をX軸の数値だけ加算していく
					// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
					g_forceArrow[i].m_chip.m_texPos.x = 150 * (g_forceArrow[i].m_animeCounter / 3);
					
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					g_forceArrow[i].m_animeCounter++;
					
					// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
					if(g_forceArrow[i].m_animeCounter >= 6 * 3)
					{
						// 戻すの！・ｗ・
						g_forceArrow[i].m_animeCounter = 0;
					}
				}
				else if (g_forceArrow[i].m_type == 3)
				{
					
					// アイテムチップの描画をX軸の数値だけ加算していく
					// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
					g_forceArrow[i].m_chip.m_texPos.x = 256 * (g_forceArrow[i].m_animeCounter / 3);
					
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					g_forceArrow[i].m_animeCounter++;
					
					// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
					if(g_forceArrow[i].m_animeCounter >= 6 * 3)
					{
						// 戻すの！・ｗ・
						g_forceArrow[i].m_animeCounter = 0;
					}
				}

			}
			
			// いちお、READYを見えないようにしておく
			g_r.m_sprite->setVisible(false);
			g_e.m_sprite->setVisible(false);
			g_a.m_sprite->setVisible(false);
			g_d.m_sprite->setVisible(false);
			g_y.m_sprite->setVisible(false);
	
			// ダブルダッシュキーが０以上の時はインクリメント
			// そうじゃない時は０を入れておく
	if(m_doubleKeyDashR > 0 || m_doubleKeyDashL > 0)
	{
		m_doubleKeyDashR--;
		m_doubleKeyDashL--;
	}
	else
	{
		m_doubleKeyDashR = 0;
		m_doubleKeyDashL = 0;
	}
	
	// ダッシュ値が３５より大きく、ダッシュフラグがオフの時はダブルキーダッシュ成功しない・ｗ・
	if (g_dashHoldCounter >= 35 || dashFlag==false)
			doubleSucsess = false;
	
	// ゲームモード ノーマルの背景スクロール処理
	if(m_scroll_X <= -480)
	{
		m_scroll_X = 0;
		m_scroll_X = 960+480;
	}
	
	if(m_scroll2_X <= -480)
	{
		m_scroll2_X = 0;
		m_scroll2_X = 480+960;
	}
	


			
	//m_scroll_X -= 5.0f;
	//m_scroll2_X -= 5.0f;
	
	
	// 基本動作設定
			// スクロールも

	if (m_LunaMuki == RIGHT)
	{
			m_luna.m_move.m_posX += m_luna.m_move.m_velX;

	}
	else
	{
			m_luna.m_move.m_posX -= m_luna.m_move.m_velX;

	}
	
	
	// ジャンプ値が一定値を超えた時の落下処理
	if(g_jumpHoldCounter >= 16)
	{
		g_jumpHoldCounter = 21;							// ジャンプ値を強制的に２１へ
		m_isPushedFlagX = false;						// Xキー多重処理フラグをオフに
		jump_power = 0;									// ジャンプのちからを一時的に０に
		m_luna.m_move.m_velY = 0;						// Y成分の速度を一時的に０に
	}
	

	// ダッシュ値が一定数になった時の処理
	// ダッシュフラグを下ろして多重ダッシュフラグをオンに、さらにダッシュ値を０に
	if (g_dashHoldCounter == 35)
	{
		// ダッシュ値が３５になったら
		// ダッシュフラグを下ろしてダッシュ前の状態に戻す
		dashFlag = false;
		
		doubleDashFlag = true;
		g_dashHoldCounter = 0;
		m_luna.m_move.m_velX = 0;
		
		
		// ここから待機アニメーション切り替え
		if (m_LunaMuki == RIGHT)
		{
			// 右なら待機アニメーション右用
			m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
		}
		else
		{
			// 左なら待機アニメーション左用
			m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
		}
	}
		
	
	// ダッシュアニメーション処理
			// 当たり判定もね！
	if (dashFlag == true && jumpFlag == false)
	{
		// センターの位置がズレるため、向きによって調整してやる
		if (m_LunaMuki == RIGHT)
		{
			// 右向き
			setChip(&m_luna.m_chip, 0, 0, 128, 64, 32, 32);
			
			setChip(&g_lunaBody[0].m_chip, 64, 6, 2, 52, 1, 26);
			setChip(&g_lunaBody[1].m_chip, 126, 6, 2, 52, 1, 26);
			setChip(&g_lunaBody[2].m_chip, 64+6, 0, 52, 2, 26, 1);
			setChip(&g_lunaBody[3].m_chip, 64+6, 62, 52, 2, 26, 1);
			setChip(&g_lunaBody[4].m_chip, 64+2, 2, 60, 60, 30, 30);
		}
		else
		{
			
			// 左向き
			setChip(&m_luna.m_chip, 0, 0, 128, 64,32, 32);
			
			setChip(&g_lunaBody[0].m_chip, 64, 6, 2, 52, 1, 26);
			setChip(&g_lunaBody[1].m_chip, 126, 6, 2, 52, 1, 26);
			setChip(&g_lunaBody[2].m_chip, 64+6, 0, 52, 2, 26, 1);
			setChip(&g_lunaBody[3].m_chip, 64+6, 62, 52, 2, 26, 1);
			setChip(&g_lunaBody[4].m_chip, 64+2, 2, 60, 60, 30, 30);
		}

	}
	// ダッシュフラグがオン・ジャンプフラグがオンの時
	else if(dashFlag == true && jumpFlag == true)
	{
		// 通常時の描画範囲に戻してあげる
		setChip(&m_luna.m_chip, 0, 0, 64, 128, 32, 64);
		
		setChip(&g_lunaBody[0].m_chip, 0, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[1].m_chip, 62, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[2].m_chip, 6, 0, 52, 2, 26, 1);
		setChip(&g_lunaBody[3].m_chip, 6, 126, 52, 2, 26, 1);
		setChip(&g_lunaBody[4].m_chip, 2, 2, 60, 124, 30, 62);
	}
	// ダッシュフラグがオフ・ジャンプフラグがオフの時
	else if(dashFlag == false && jumpFlag == false)
	{
		// 通常時の描画範囲に戻してあげる
		setChip(&m_luna.m_chip, 0, 0, 64, 128, 32, 64);

		setChip(&g_lunaBody[0].m_chip, 0, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[1].m_chip, 62, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[2].m_chip, 6, 0, 52, 2, 26, 1);
		setChip(&g_lunaBody[3].m_chip, 6, 126, 52, 2, 26, 1);
		setChip(&g_lunaBody[4].m_chip, 2, 2, 60, 124, 30, 62);
	}
	else
	{
		// 通常時の描画範囲に戻してあげる
		setChip(&m_luna.m_chip, 0, 0, 64, 128, 32, 64);
		
		setChip(&g_lunaBody[0].m_chip, 0, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[1].m_chip, 62, 6, 2, 116, 1, 58);
		setChip(&g_lunaBody[2].m_chip, 6, 0, 52, 2, 26, 1);
		setChip(&g_lunaBody[3].m_chip, 6, 126, 52, 2, 26, 1);
		setChip(&g_lunaBody[4].m_chip, 2, 2, 60, 124, 30, 62);
	}

	// 落下処理
	// ここに壁蹴り処理を加える
	if(g_checkStandGround == 0 && g_jumpHoldCounter <= 16 )
	{
		m_luna.m_move.m_posY += m_luna.m_move.m_velY + gravity;
	}
	else if(g_checkStandGround > 0 && g_jumpHoldCounter <= 16 )
	{
		m_luna.m_move.m_posY += m_luna.m_move.m_velY ;
	}
	else if(g_checkStandGround == 0 && g_jumpHoldCounter >= 17 )
	{
		m_luna.m_move.m_posY += m_luna.m_move.m_velY + gravity -10;
	}
	
    if (wallStickRight == true || wallStickRight == true)
	{
		gravity = -3.0;
		dashFlag = false;
		dashJumpFlag = false;
		g_jumpHoldCounter = 0;
	}
	else
	{
		gravity = -9.8;
	}

	
			if(g_jumpHoldCounter <= 16)
			{

				// ジャンプアニメーション処理
				// 右向きなら
				if (m_LunaMuki == RIGHT && jumpFlag == true)
				{
					// 右向き用のジャンプアニメーションに
					// 壁蹴り開始・壁蹴り中・ジャンプ頂点・壁貼り付き開始・壁張り付き中でない時
					if ((m_lunaAnimation != kLunaAnimation::KICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_START_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::KICK_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::JUMP_TOP_RIGHT || m_lunaAnimation != kLunaAnimation::JUMP_TOP_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::WALLSTICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_START_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::WALLSTICK_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_LEFT))
					{
						m_lunaAnimation = kLunaAnimation::JUMP_RIGHT;
					}
					
				}else if(m_LunaMuki == LEFT && jumpFlag == true){
					// 左向き用のアニメーションに
					// 壁蹴り開始・壁蹴り中・ジャンプ頂点・壁貼り付き開始・壁張り付き中でない時
					if ((m_lunaAnimation != kLunaAnimation::KICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_START_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::KICK_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::JUMP_TOP_RIGHT || m_lunaAnimation != kLunaAnimation::JUMP_TOP_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::WALLSTICK_START_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_START_LEFT) &&
						(m_lunaAnimation != kLunaAnimation::WALLSTICK_RIGHT || m_lunaAnimation != kLunaAnimation::WALLSTICK_LEFT) )
					{
						m_lunaAnimation = kLunaAnimation::JUMP_LEFT;
					}
				}
			}
	
	// ダッシュフラグがオンになったら位置を下に少しずらす
	// ここでルナのじったいそのものを変えておく必要がある
	if(dashFlag && jumpFlag == false)
	{
		m_luna.m_move.m_posY = m_luna.m_move.m_posY-32;
	}
	
	// ジャンプ値が一定数値を超えた時・ジャンプ中の時・落下中ではない時・壁蹴り中ではない時
	if ((g_jumpHoldCounter >= 21 )&& (m_lunaAnimation == kLunaAnimation::JUMP_RIGHT || m_lunaAnimation == kLunaAnimation::JUMP_LEFT) &&
		(m_lunaAnimation != kLunaAnimation::FALL_RIGHT || m_lunaAnimation != kLunaAnimation::FALL_LEFT)
		&& (m_lunaAnimation != kLunaAnimation::KICK_RIGHT || m_lunaAnimation != kLunaAnimation::KICK_LEFT ))
	{
		// ルナのY方向の働きを０にする。
		// g_jumpHoldCounter=0;
		 m_luna.m_move.m_velY -= 10.8f;
	}
	
	
	// ルナの行動制限
	this->restrictMoveMyShip();
	
	// ルナのアニメーション処理
	this->lunaAnimation();
	
	// ふぉーすあろーの移動処理
	this->moveMyBullet();
	
	// アニメーションが待機モーションに戻る
	if (g_shotAnimationTime > 0 &&
		((m_lunaAnimation == kLunaAnimation::SHOT_RIGHT || m_lunaAnimation == kLunaAnimation::SHOT_LEFT) ||
		 (m_lunaAnimation == kLunaAnimation::WALK_RIGHT || m_lunaAnimation == kLunaAnimation::WALK_LEFT)))
	{
		// ショットアニメーションカウンタをデクリメント
		g_shotAnimationTime--;
	}
	
	if (g_shotAnimationTime == 0 && ((m_lunaAnimation == kLunaAnimation::SHOT_RIGHT || m_lunaAnimation == kLunaAnimation::SHOT_LEFT)
		|| (m_lunaAnimation == kLunaAnimation::WALK_RIGHT || m_lunaAnimation == kLunaAnimation::WALK_LEFT)))
	{
		// ショットアニメーションが０になったら値を-1にしてデクリメントを止める
		g_shotAnimationTime = -1;
	}
	
	// ショットアニメーションタイムが−１のとき・ショットアニメーションが再生中 または 歩行アニメーションが再生中
	// 待機モーションに戻る
	if (g_shotAnimationTime == -1 && ((m_lunaAnimation == kLunaAnimation::SHOT_RIGHT || m_lunaAnimation == kLunaAnimation::SHOT_LEFT)
		|| (m_lunaAnimation == kLunaAnimation::WALK_RIGHT || m_lunaAnimation == kLunaAnimation::WALK_LEFT)))
	{
		if (m_LunaMuki == RIGHT)
		{
			// 右なら待機アニメーション右用
			m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
		}
		else
		{
			// 左なら待機アニメーション左用
			m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
		}
	}
			this->intersectsLunaAndBlocksRight();
			this->intersectsLunaAndBlocksLeft();
			
		/*
			for(int i = 0; i < MAX_BLOCK; i++)
			{
			if(m_luna.m_move.m_posX >= g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x &&
			   m_luna.m_move.m_posX <= g_block[i].m_move.m_posX + g_block[i].m_chip.m_center.x)
			*/
			
			this->intersectsLunaAndBlocksTop();
			this->intersectsLunaAndBlocksBottom();
			
			
			this->intersectsLunaAndGroundBottom();
	
			break;
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//
	// ぽぉずもぉど・ｗ・ｂ
	//
	case kGameMode::kGameMode_PAUSE:
		{
			// なにかさせたいならここに処理を書く・ｗ・ｂ
			
			// ポーズ中はBGM再生ボリュームを全て0.1に指定しておく
			SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0.1);
		}
		break;
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		default:
			break;
}
	// データエレメンタルをポーズ中以外の時に常に表示
	this->debugUpdate();
	 
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//=============================================================================
//	drawAll
//		描画処理
//		描画自体は cocos2d が管理しているのでここでは Sprite の設定管理のみを行う
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================	
void GameMain::drawAll()
{
	
	//
	// ゲームモードの追加
	//
	switch (m_gameMode)
	{
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
		// ポーズ中 描画処理
		case kGameMode::kGameMode_STOP:
			
			//
			// R E A D Y ? チップ
			//
			
			// R
			if(g_r.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_r.m_chip.m_texPos.x;
				chipData.origin.y = g_r.m_chip.m_texPos.y;
				chipData.size.width = g_r.m_chip.m_size.x;
				chipData.size.height = g_r.m_chip.m_size.y;
				
				g_r.m_sprite->setTextureRect( chipData);
				
				g_r.m_sprite->setPosition(g_r.m_move.m_posX, g_r.m_move.m_posY);
			}
			// E
			if(g_e.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_e.m_chip.m_texPos.x;
				chipData.origin.y = g_e.m_chip.m_texPos.y;
				chipData.size.width = g_e.m_chip.m_size.x;
				chipData.size.height = g_e.m_chip.m_size.y;
				
				g_e.m_sprite->setTextureRect( chipData);
				
				g_e.m_sprite->setPosition(g_e.m_move.m_posX, g_e.m_move.m_posY);
			}
			// A
			if(g_a.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_a.m_chip.m_texPos.x;
				chipData.origin.y = g_a.m_chip.m_texPos.y;
				chipData.size.width = g_a.m_chip.m_size.x;
				chipData.size.height = g_a.m_chip.m_size.y;
				
				g_a.m_sprite->setTextureRect( chipData);
				
				g_a.m_sprite->setPosition(g_a.m_move.m_posX, g_a.m_move.m_posY);
			}
			// D
			if(g_d.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_d.m_chip.m_texPos.x;
				chipData.origin.y = g_d.m_chip.m_texPos.y;
				chipData.size.width = g_d.m_chip.m_size.x;
				chipData.size.height = g_d.m_chip.m_size.y;
				
				g_d.m_sprite->setTextureRect( chipData);
				
				g_d.m_sprite->setPosition(g_d.m_move.m_posX, g_d.m_move.m_posY);
			}
			
			// Y
			if(g_y.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_y.m_chip.m_texPos.x;
				chipData.origin.y = g_y.m_chip.m_texPos.y;
				chipData.size.width = g_y.m_chip.m_size.x;
				chipData.size.height = g_y.m_chip.m_size.y;
				
				g_y.m_sprite->setTextureRect( chipData);
				
				g_y.m_sprite->setPosition(g_y.m_move.m_posX, g_y.m_move.m_posY);
			}
			
			break;
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			//
			// イベントモード！
			//
			
		case kGameMode::kGameMode_EVENT:
			/*
			if(g_lunaFace.m_sprite != NULL)
			{
				Rect chipData;
				
				chipData.origin.x = g_lunaFace.m_chip.m_texPos.x;
				chipData.origin.y = g_lunaFace.m_chip.m_texPos.y;
				chipData.size.width = g_lunaFace.m_chip.m_size.x;
				chipData.size.height = g_lunaFace.m_chip.m_size.y;
				
				g_lunaFace.m_sprite->setTextureRect( chipData);
				
				g_lunaFace.m_sprite->setPosition(g_lunaFace.m_move.m_posX, g_lunaFace.m_move.m_posY);
			}
*/
			
			break;
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
			//
			// のーまるもぉど・ｗ・
			//
			
		case kGameMode::kGameMode_NORMAL:
		{
			// ポーズ時も描画されてるのでここは何も書かなくていいのよ・ｗ・
			// 形だけ書いておくの・ｗ・人
			
			m_luna.m_sprite->setOpacity(g_lunaOpacity);
		}
			break;
			
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
			//
			// ぽぉずもぉど・ｗ・ｂ
			//
		case kGameMode::kGameMode_PAUSE:
		{
			
			// ポーズ画像のみはポーズした時にしか表示されないのでここにコードを書く・ｗ・ｂ
			// テクスチャを切り取らなければいけない時は cocos2d::Rect も用意してやること・ｗ・ｂ
			// 今回は一枚絵なので位置のみ設定しておく・ｗ・人
			
			
			if( g_pMenu != NULL )
			{
				
				g_pMenu->setPosition(480, 360);
				
			}
			 
		}
			break;
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			
		default:
			break;
	}

	// 背景の描画
	if( g_pBg != NULL){
		g_pBg->setPosition(m_scroll_X, 360 );
		g_pBg2->setPosition(m_scroll2_X, 360 );
		g_pBg3->setPosition(m_scroll3_X, 360 );
	}
	
	// 地面の描画
	if( g_pGround.m_sprite != NULL)
	{
		Rect chipData;
		
		chipData.origin.x = g_pGround.m_chip.m_texPos.x;
		chipData.origin.y = g_pGround.m_chip.m_texPos.y;
		chipData.size.width = g_pGround.m_chip.m_size.x;
		chipData.size.height = g_pGround.m_chip.m_size.y;
		
		g_pGround.m_sprite->setTextureRect(chipData);
		
		g_pGround.m_sprite->setPosition(g_pGround.m_move.m_posX, g_pGround.m_move.m_posY);
	}
	
	// 地面の描画
	if( g_ui != NULL)
	{
		g_ui->setPosition(480, 360);
	}
	
	// ブロックの描画
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		if( g_block[i].m_sprite != NULL)
		{
			Rect chipData;
			
			chipData.origin.x = g_block[i].m_chip.m_texPos.x;
			chipData.origin.y = g_block[i].m_chip.m_texPos.y;
			chipData.size.width = g_block[i].m_chip.m_size.x;
			chipData.size.height = g_block[i].m_chip.m_size.y;
			
			g_block[i].m_sprite->setTextureRect( chipData);
			
			g_block[i].m_sprite->setPosition(g_block[i].m_move.m_posX, g_block[i].m_move.m_posY);
		}
	}
	// ルナの描画設定
	if(m_luna.m_sprite != NULL){
		Rect chipData;
		
		chipData.origin.x = m_luna.m_chip.m_texPos.x;
		chipData.origin.y = m_luna.m_chip.m_texPos.y;
		chipData.size.width = m_luna.m_chip.m_size.x;
		chipData.size.height = m_luna.m_chip.m_size.y;
		
		m_luna.m_sprite->setTextureRect( chipData);
		
		m_luna.m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	}
	
	// ふぉーすあろーの描画処理
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (g_forceArrow[i].m_activeFlag == true)
		{
			Rect chipData;
			chipData.origin.x = g_forceArrow[i].m_chip.m_texPos.x;
			chipData.origin.y = g_forceArrow[i].m_chip.m_texPos.y;
			chipData.size.width = g_forceArrow[i].m_chip.m_size.x;
			chipData.size.height = g_forceArrow[i].m_chip.m_size.y;
			
			g_forceArrow[i].m_sprite->setTextureRect(chipData);
			
			g_forceArrow[i].m_sprite->setPosition(g_forceArrow[i].m_move.m_posX, g_forceArrow[i].m_move.m_posY);
		}
	}
	
	// しゅーてぃんぐ ぶれいずの描画処理
	for (int i = 0; i < MAX_SBLAZE; i++)
	{
		if (g_shootingBlaze[i].m_activeFlag == true)
		{
			Rect chipData;
			chipData.origin.x = g_shootingBlaze[i].m_chip.m_texPos.x;
			chipData.origin.y = g_shootingBlaze[i].m_chip.m_texPos.y;
			chipData.size.width = g_shootingBlaze[i].m_chip.m_size.x;
			chipData.size.height = g_shootingBlaze[i].m_chip.m_size.y;
			
			g_shootingBlaze[i].m_sprite->setTextureRect(chipData);
			
			g_shootingBlaze[i].m_sprite->setPosition(g_shootingBlaze[i].m_move.m_posX, g_shootingBlaze[i].m_move.m_posY);
		}
	}

	
	// 砂埃の描画処理
	for (int i = 0; i < MAX_SMOKE; i++)
	{
		if (g_smoke[i].m_activeFlag == true)
		{
			Rect chipData;
			chipData.origin.x = g_smoke[i].m_chip.m_texPos.x;
			chipData.origin.y = g_smoke[i].m_chip.m_texPos.y;
			chipData.size.width = g_smoke[i].m_chip.m_size.x;
			chipData.size.height = g_smoke[i].m_chip.m_size.y;
			
			g_smoke[i].m_sprite->setTextureRect(chipData);
			
			g_smoke[i].m_sprite->setPosition(g_smoke[i].m_move.m_posX, g_smoke[i].m_move.m_posY);
		}
	}
	
	// ルナの実体の描画処理
	for (int i = 0; i < LUNA_BODY; i++)
	{
		if (g_lunaBody[i].m_activeFlag == true)
		{
			Rect chipData;
			chipData.origin.x = g_lunaBody[i].m_chip.m_texPos.x;
			chipData.origin.y = g_lunaBody[i].m_chip.m_texPos.y;
			chipData.size.width = g_lunaBody[i].m_chip.m_size.x;
			chipData.size.height = g_lunaBody[i].m_chip.m_size.y;
			
			g_lunaBody[i].m_sprite->setTextureRect(chipData);
			
			// g_lunaBody[i].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
		}
	}
	
	// ダッシュ中
	if (dashFlag == true && jumpFlag == false)
	{
		g_lunaBody[0].m_sprite->setPosition(m_luna.m_move.m_posX -31, m_luna.m_move.m_posY);
		g_lunaBody[1].m_sprite->setPosition(m_luna.m_move.m_posX +31, m_luna.m_move.m_posY);
		g_lunaBody[2].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 31);
		g_lunaBody[3].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 31);
		g_lunaBody[4].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	}
	else if(dashFlag == true && jumpFlag == true)
	{
		g_lunaBody[0].m_sprite->setPosition(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
		g_lunaBody[1].m_sprite->setPosition(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
		g_lunaBody[2].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
		g_lunaBody[3].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
		g_lunaBody[4].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	}
	else if (dashFlag == false && jumpFlag == false)
	{
		g_lunaBody[0].m_sprite->setPosition(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
		g_lunaBody[1].m_sprite->setPosition(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
		g_lunaBody[2].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
		g_lunaBody[3].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
		g_lunaBody[4].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	}
	else
	{
		g_lunaBody[0].m_sprite->setPosition(m_luna.m_move.m_posX - 31, m_luna.m_move.m_posY);
		g_lunaBody[1].m_sprite->setPosition(m_luna.m_move.m_posX + 31, m_luna.m_move.m_posY);
		g_lunaBody[2].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY + 63);
		g_lunaBody[3].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY - 63);
		g_lunaBody[4].m_sprite->setPosition(m_luna.m_move.m_posX, m_luna.m_move.m_posY);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//=============================================================================
//	launchEnemy
//		敵機の出撃
//	-----------------------------------------------------------------------
//	INPUT:	ENEMY_TYPE			敵機タイプ
//	OUTPUT:	bool	true...敵出撃
//					false...空き敵機無し
//	-----------------------------------------------------------------------
//	TIPS:	VERSION	5.0 で外部ファイルに移動させクラス化する
//=============================================================================
bool GameMain::launchEnemy( kENEMY_TYPE eneType )
{
	return true ;
}


//
// しゅーてぃんぐ ぶれいず
//
bool GameMain::shootingBlaze( CCharacter* pChr, CCharacter sbArray[], int arraySize, int offsetX, int offsetY, float velX, float velY)
{
	int index = getFreeCharacterIndex(sbArray, arraySize);
	if(index == NO_DATA)
		return false;
	
	// 発射位置を指定するよ！・ｗ・
	sbArray[index].m_move.setMovePos(pChr->m_move.m_posX + offsetX, pChr->m_move.m_posY + offsetY);
	
	if (m_LunaMuki == RIGHT)
		setChip(&sbArray[index].m_chip, 0, 0, 192, 128, 96, 64);
	else
		setChip(&sbArray[index].m_chip, 0, 128, 192, 128, 96, 64);
	
	sbArray[index].m_move.setMoveVel(velX, velY);
	
	// アニメーションカウンタを０にしてアニメーションの始まりを均一化する
	sbArray[index].m_animeCounter = 0;
	sbArray[index].m_activeFlag = true;
	sbArray[index].m_sprite->setVisible(true);
	
	return true;
}



//=============================================================================
//	shootBullet
//		弾の発射
//	-----------------------------------------------------------------------
//	INPUT:	CHARACTER* pChr			弾を発射するキャラクター
//			CHARACTER bulArray[]	弾配列
//			int arraySize			弾配列のサイズ
//			int offsetX				発射位置のオフセット（ずれ）X成分
//			int offsetY				発射位置のオフセット（ずれ）Y成分
//			float velX				速度 X 成分
//			float velY				速度 Y 成分
//			kBULLET_TYPE type		弾タイプ
//	OUTPUT:	void
//	-----------------------------------------------------------------------
//	TIPS:	外部ファイルに移動させクラス化する
//=============================================================================
bool GameMain::shootBullet( CCharacter* pChr, CCharacter bulArray[], int arraySize, int offsetX, int offsetY, float velX, float velY, kBULLET_TYPE type )
{
	// 画面上にふぉーすあろーは３つまでしか存在できないので activeFlag が false になってるふぉーすあろーを探して再利用
	// 全部 true ならこの関数での処理は行われない
	int index = getFreeCharacterIndex(bulArray, arraySize);
	if(index == NO_DATA)
		return false;
	
	// 発射位置を指定するよ！・ｗ・
	bulArray[index].m_move.setMovePos(pChr->m_move.m_posX + offsetX, pChr->m_move.m_posY + offsetY);
	
	switch (type)
	{
			// ふぉーすあろーチャージなしの場合
			// ふぉーすあろーのメンバ変数に「１」を渡してアニメーションに識別する
		case kBULLET_TYPE::CHARGE_LITTLE:
			setChip(&bulArray[index].m_chip, 0, 0, 16, 16, 8, 8);
			bulArray[index].m_move.setMoveVel(velX, velY);
			bulArray[index].m_type = 1;
			break;
			
			// ふぉーすあろーチャージ中の場合
			// ふぉーすあろーのメンバ変数に「２」を渡してアニメーションに識別する
		case kBULLET_TYPE::CHARGE_MIDDLE:
			
			// 右向き左向きでセットチップが異なる
			if (m_LunaMuki == RIGHT)
				setChip(&bulArray[index].m_chip, 0, 16, 150, 128, 8, 8);
			else
				setChip(&bulArray[index].m_chip, 0, 16+128+128, 150, 128, 8, 8);
				
			bulArray[index].m_move.setMoveVel(velX, velY);
			bulArray[index].m_type = 2;
			break;
			
			// はいぱーふぉーすあろーの場合
			// ふぉーすあろーのメンバ変数に「３」を渡してアニメーションに識別する
		case kBULLET_TYPE::CHARGE_BIG:
			
			// 右向き左向きでセットチップが異なる
			if (m_LunaMuki == RIGHT)
				setChip(&bulArray[index].m_chip, 0, 128+16, 256, 128, 128, 64);
			else
				setChip(&bulArray[index].m_chip, 0, 128+16+256, 256, 128, 128, 64);
			
			bulArray[index].m_move.setMoveVel(velX, velY);
			bulArray[index].m_type = 3;
			break;
						
		default:
			break;
	}
	
	// アニメーションカウンタを０にしてアニメーションの始まりを均一化する
	bulArray[index].m_animeCounter = 0;
	bulArray[index].m_activeFlag = true;
	bulArray[index].m_sprite->setVisible(true);
	return true ;
}

//
// 砂煙つけるよ！・ｗ・
//
//=============================================================================
//	smoke
//		ダッシュ時の砂ホコリの出撃
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
bool GameMain::smoke( CCharacter* pChr, CCharacter smokeArray[], int arraySize, int offsetX, int offsetY)
{
	int index = getFreeCharacterIndex(smokeArray, arraySize);
	
	if(index == NO_DATA)
		return false;
	
	smokeArray[index].m_move.setMovePos(pChr->m_move.m_posX + offsetX, pChr->m_move.m_posY + offsetY);
	
	if (m_LunaMuki == RIGHT)
	{
		// 右ならこっち
		setChip(&smokeArray[index].m_chip, 0, 0, 64, 64, 32, 32);
		smokeArray[index].m_move.setMoveVel(0.0f, 0.0f);
	}
	else
	{
		// 左ならこれ！・ｗ・
		setChip(&smokeArray[index].m_chip, 0, 64, 64, 64, 32, 32);
		smokeArray[index].m_move.setMoveVel(0.0f, 0.0f);
	}
	
	// こちらもふぉーすあろーアニメーションと同様にアニメーションカウンタを０にしておく
	smokeArray[index].m_animeCounter = 0;
	smokeArray[index].m_activeFlag = true;
	smokeArray[index].m_sprite->setVisible(true);
	return true;
}

//
// しゅーてぃんぐ ぶれいず発射！
//
void GameMain::Spell_shootingBlaze()
{
	bool launchFlag = false;
	
	if(dashFlag == true)
	{
		// ダッシュ時、右向きの処理
		if (m_LunaMuki == RIGHT)
		{
			// ジャンプ中
			if(dashJumpFlag)
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, 32, 4, 40.0f, -10.0f);
				m_sb_rotation = 10;
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
			else
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, 32, 4, 40.0f, 0.0f);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
		}
		// ダッシュ時、左向きの処理
		if (m_LunaMuki == LEFT)
		{
			// ジャンプ中
			if(dashJumpFlag)
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, -32, 4, -40.0f, -10.0f);
				m_sb_rotation = -10;
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
			else
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, -32, 4, -40.0f, 0.0f);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
		}
		
	}
	else
	{
		
		// 通常時右向きの処理
		if (m_LunaMuki == RIGHT)
		{
			if(jumpFlag)
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, 8, 4, 35.0f, -25.0f);
				m_sb_rotation = 35;
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
			else
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, 32, 4, 35.0f, 0.0f);
				m_sb_rotation = 0;
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
		}
		
		
		// 通常時左向きの処理
		if (m_LunaMuki == LEFT)
		{
			if(jumpFlag)
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, -8, 4, -35.0f,-25.0f);
				m_sb_rotation = -35;
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
			else
			{
				launchFlag = this->shootingBlaze(&m_luna, g_shootingBlaze, MAX_SBLAZE, -32, 4, -35.0f, 0.0f);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_sBNumber += 1;
			}
		}
		
	}
	
	// ふぉーすあろーが発射されていたら
	if (launchFlag == true)
	{
		// リセットします
		m_luna.m_shotCounter = g_forceArrowIntervalTime;
		
	}

}

//=============================================================================
//	shootMyBullet
//		自弾の発射処理
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::shootMyBullet()
{
	bool launchFlag = false;
	
	if(g_chargeHoldCounter <= 10)
	{
		if(dashFlag == true)
		{
			// ダッシュ時、右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 32, 4, 20.0f, 0.0f, kBULLET_TYPE::CHARGE_LITTLE);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// ダッシュ時、左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -32, 4, -20.0f, 0.0f, kBULLET_TYPE::CHARGE_LITTLE);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
		
		}
		else
		{
			
			// 通常時右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 32, 4, 15.0f, 0.0f, kBULLET_TYPE::CHARGE_LITTLE);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// 通常時左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -32, 4, -15.0f, 0.0f, kBULLET_TYPE::CHARGE_LITTLE);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			
		}
	}
	// はいぱーふぉーすあろー チャージ中
	else if(g_chargeHoldCounter >= 10 && g_chargeHoldCounter <= 100)
	{
		if(dashFlag == true)
		{
			// ダッシュ時、右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 32, 4, 30.0f, 0.0f, kBULLET_TYPE::CHARGE_MIDDLE);
				SimpleAudioEngine::getInstance()->playEffect("middle_fa3.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("LDash.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// ダッシュ時、左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -32, 4, -30.0f, 0.0f, kBULLET_TYPE::CHARGE_MIDDLE);
				SimpleAudioEngine::getInstance()->playEffect("middle_fa3.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("LDash.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			
		}
		else
		{
			
			// 通常時右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 32, 4, 25.0f, 0.0f, kBULLET_TYPE::CHARGE_MIDDLE);
				SimpleAudioEngine::getInstance()->playEffect("middle_fa3.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("LDash.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// 通常時左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -32, 4, -25.0f, 0.0f, kBULLET_TYPE::CHARGE_MIDDLE);
				SimpleAudioEngine::getInstance()->playEffect("middle_fa3.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("LDash.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			
		}
	}
	// はいぱーふぉーすあろー チャージ大
	else if( g_chargeHoldCounter >= 100)
	{
		if(dashFlag == true)
		{
			// ダッシュ時、右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 64, 4, 40.0f, 0.0f, kBULLET_TYPE::CHARGE_BIG);
				
				SimpleAudioEngine::getInstance()->playEffect("forceArrow_MAXCharge.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("chargeShotVoice.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// ダッシュ時、左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -64, 4, -40.0f, 0.0f, kBULLET_TYPE::CHARGE_BIG);
				
				SimpleAudioEngine::getInstance()->playEffect("forceArrow_MAXCharge.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("chargeShotVoice.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			
		}
		else
		{
			
			// 通常時右向きの処理
			if (m_LunaMuki == RIGHT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, 64, 4, 35.0f, 0.0f, kBULLET_TYPE::CHARGE_BIG);
				
				
				SimpleAudioEngine::getInstance()->playEffect("forceArrow_MAXCharge.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("chargeShotVoice.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			// 通常時左向きの処理
			if (m_LunaMuki == LEFT)
			{
				launchFlag = this->shootBullet(&m_luna, g_forceArrow, MAX_BULLET, -64, 4, -35.0f, 0.0f, kBULLET_TYPE::CHARGE_BIG);
				
				SimpleAudioEngine::getInstance()->playEffect("forceArrow_MAXCharge.wav",false);
				SimpleAudioEngine::getInstance()->playEffect("chargeShotVoice.wav",false);
				// 発射されたふぉーすあろー１つにつき１個カウンタを増やす
				g_forceArrowNumber += 1;
			}
			
		}
	}

	
	// ふぉーすあろーが発射されていたら
	if (launchFlag == true)
	{
		// リセットします
		m_luna.m_shotCounter = g_forceArrowIntervalTime;
		
	}
}

//=============================================================================
//	shootEnemyBullet
//		敵弾の発射処理
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::shootEnemyBullet()
{

}



//=============================================================================
//	restrictMoveMyShip
//		自機の移動制限
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::restrictMoveMyShip()
{
	// ウィンドウサイズを取得
	Size windowSize = Director::getInstance()->getVisibleSize();
	
	// 左端の制限
    if(m_luna.m_move.m_posX < (m_luna.m_chip.m_center.x))
    {
        m_luna.m_move.m_posX = m_luna.m_chip.m_center.x;
    }
    
    //右端への移動制限
	if(m_LunaMuki == RIGHT)
	{
		if(m_luna.m_move.m_posX > (windowSize.width + m_luna.m_chip.m_center.x - m_luna.m_chip.m_size.x ))
		{
			if(dashFlag && jumpFlag == false)
				m_luna.m_move.m_posX = windowSize.width + m_luna.m_chip.m_center.x - m_luna.m_chip.m_size.x+64;
			else if(dashJumpFlag)
				m_luna.m_move.m_posX = windowSize.width + m_luna.m_chip.m_center.x - m_luna.m_chip.m_size.x;
			else
				m_luna.m_move.m_posX = windowSize.width + m_luna.m_chip.m_center.x - m_luna.m_chip.m_size.x;
		}
    }
    
    // 下の移動制限
    // widthをheightに変えて上記と同じようにするのよ〜 ・ｗ・人
    if(m_luna.m_move.m_posY < (m_luna.m_chip.m_center.y))
    {
        m_luna.m_move.m_posY = m_luna.m_chip.m_center.y;
    }
    
    // 上方向の移動制限
    // 下方向の移動制限に同じ
    if(m_luna.m_move.m_posY > (windowSize.height + m_luna.m_chip.m_center.y - m_luna.m_chip.m_size.y))
    {
        m_luna.m_move.m_posY = windowSize.height + m_luna.m_chip.m_center.y - m_luna.m_chip.m_size.y;
    }
}

//=============================================================================
//	moveEnemy
//		敵の移動
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::moveEnemy()
{

}

//=============================================================================
//	moveMyBullet
//		自弾の移動
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::moveMyBullet()
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (g_forceArrow[i].m_activeFlag == true)
		{
			// 速度による運動
			g_forceArrow[i].m_move.moveByVel();
			
			// 画面外処理
			if (!isInArea(&g_forceArrow[i], g_screenArea)) {
				// アクティブフラグ及び描画を止め、ふぉーすあろーの個数カウンタを１個減らす
				g_forceArrow[i].m_activeFlag = false;
				g_forceArrow[i].m_sprite->setVisible(false);
				g_forceArrowNumber -= 1;
			}
		}
	}
	
	// しゅーてぃんぐ ぶれいずの動き
	for (int i = 0; i < MAX_SBLAZE; i++)
	{
		if (g_shootingBlaze[i].m_activeFlag == true)
		{
			// 速度による運動
			g_shootingBlaze[i].m_move.moveByVel();
			
			// 画面外処理
			if (!isInArea(&g_shootingBlaze[i], g_screenArea))
			{
				// アクティブフラグ及び描画を止め、ふぉーすあろーの個数カウンタを１個減らす
				g_shootingBlaze[i].m_activeFlag = false;
				g_shootingBlaze[i].m_sprite->setVisible(false);
				g_sBNumber -= 1;
			}
		}
	}

	
}




//=============================================================================
//
//
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsLunaAndBlocksLeft()
{
	//
	// ここは左側の判定！
	//
	
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		// 生存している敵全てと衝突判定を行う
		if (g_block[i].m_activeFlag == true )
		{
			// スクリーン上でのそれぞれの短形の位置を計算する
			
			// 自機の短形を計算！・ｗ・
			RECT rectA;
			rectA.left = g_lunaBody[0].m_move.m_posX - g_lunaBody[0].m_chip.m_center.x + g_lunaBody[0].m_body.left;
			rectA.top = g_lunaBody[0].m_move.m_posY + g_lunaBody[0].m_chip.m_center.y - g_lunaBody[0].m_body.top;
			rectA.right = g_lunaBody[0].m_move.m_posX - g_lunaBody[0].m_chip.m_center.x + g_lunaBody[0].m_body.right;
			rectA.bottom = g_lunaBody[0].m_move.m_posY + g_lunaBody[0].m_chip.m_center.y - g_lunaBody[0].m_body.bottom;
			
			// 敵機の短形を計算
			RECT rectB;
			rectB.left = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.left;
			rectB.top = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.top;
			rectB.right = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.right;
			rectB.bottom = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.bottom;
			
			// 短形同士の重なりを判定
			if( collisionRect(&rectA, &rectB) == true )
			{
				
				if(dashFlag == true&& m_LunaMuki == LEFT)
				{
					dashFlag = false;
					g_dashHoldCounter = 0;
					//g_intersect_LEFT = true;
					m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX + m_luna.m_chip.m_center.x + g_block[i].m_chip.m_center.x - 1;
				}

				// 衝突した際は自機と敵の生存フラグと表示設定をtrueにする
				if(dashFlag == false && IsKeyPressed(KEY_FLAG::RIGHT) == false)
				{
					g_intersect_LEFT = true;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX + m_luna.m_chip.m_center.x + g_block[i].m_chip.m_center.x - 1;
				}
				else if(m_LunaMuki == LEFT)
				{
					g_intersect_LEFT = false;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX + m_luna.m_chip.m_center.x + g_block[i].m_chip.m_center.x;
				}
				

			}
			else
				g_intersect_LEFT = false;
		}
	}
}
//=============================================================================
//	intersectsMyBulletAndEnemy
//		ブロックとルナとの右側の判定
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsLunaAndBlocksRight()
{
	//
	// ここは右側の判定！
	//
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		// 生存している敵全てと衝突判定を行う
		if (g_block[i].m_activeFlag == true )
		{
			// スクリーン上でのそれぞれの短形の位置を計算する
			
			// 自機の短形を計算！・ｗ・
			RECT rectA;
			rectA.left = g_lunaBody[1].m_move.m_posX - g_lunaBody[1].m_chip.m_center.x + g_lunaBody[1].m_body.left;
			rectA.top = g_lunaBody[1].m_move.m_posY + g_lunaBody[1].m_chip.m_center.y - g_lunaBody[1].m_body.top;
			rectA.right = g_lunaBody[1].m_move.m_posX - g_lunaBody[1].m_chip.m_center.x + g_lunaBody[1].m_body.right;
			rectA.bottom = g_lunaBody[1].m_move.m_posY + g_lunaBody[1].m_chip.m_center.y - g_lunaBody[1].m_body.bottom;
			
			// 敵機の短形を計算
			RECT rectB;
			rectB.left = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.left;
			rectB.top = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.top;
			rectB.right = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.right;
			rectB.bottom = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.bottom;
			
			// 短形同士の重なりを判定
			if( collisionRect(&rectA, &rectB) == true )
			{
				
				if( dashFlag == true && m_LunaMuki == RIGHT)
				{
					dashFlag = false;
					g_dashHoldCounter = 0;
					//g_intersect_RIGHT = true;
					m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX - m_luna.m_chip.m_center.x - g_block[i].m_chip.m_center.x + 1  ;
				}
				
				// 衝突した際は自機と敵の生存フラグと表示設定をtrueにする
				if(dashFlag == false && IsKeyPressed(KEY_FLAG::LEFT) == false)
				{
					g_intersect_RIGHT = true;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX - m_luna.m_chip.m_center.x - g_block[i].m_chip.m_center.x + 1;
				}
				else if(m_LunaMuki == RIGHT)
				{
					g_intersect_RIGHT = false;
					m_luna.m_move.m_posX = g_block[i].m_move.m_posX - m_luna.m_chip.m_center.x - g_block[i].m_chip.m_center.x;
				}
				
			}
			else
			{
				g_intersect_RIGHT = false;
			}
		}
	}
}




//=============================================================================
//
//
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsLunaAndBlocksTop()
{
	//
	// ここは下側の判定！
	//
	
	// 生存している敵全てと衝突判定を行う
	
	// スクリーン上でのそれぞれの短形の位置を計算する
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		if(g_block[i].m_activeFlag == true)
		{
		// 自機の短形を計算！・ｗ・
		RECT rectA;
		rectA.left = g_lunaBody[2].m_move.m_posX - g_lunaBody[2].m_chip.m_center.x + g_lunaBody[2].m_body.left;
		rectA.top = g_lunaBody[2].m_move.m_posY + g_lunaBody[2].m_chip.m_center.y - g_lunaBody[2].m_body.top;
		rectA.right = g_lunaBody[2].m_move.m_posX - g_lunaBody[2].m_chip.m_center.x + g_lunaBody[2].m_body.right;
		rectA.bottom = g_lunaBody[2].m_move.m_posY + g_lunaBody[2].m_chip.m_center.y - g_lunaBody[2].m_body.bottom;
		
		// 敵機の短形を計算
		RECT rectB;
		rectB.left = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.left;
		rectB.top = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.top;
		rectB.right = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.right;
		rectB.bottom = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.bottom;
		
		// 短形同士の重なりを判定
		if( collisionRect(&rectA, &rectB) == true)
		{
			if(m_luna.m_move.m_posY + m_luna.m_chip.m_center.y <= g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y)
			{
				if(g_jumpHoldCounter <= 16)
				{
					m_luna.m_move.m_posY = g_block[i].m_move.m_posY - m_luna.m_chip.m_center.y - g_block[i].m_chip.m_center.y + 1;
					g_intersect_TOP = true;
					g_jumpHoldCounter = 21;
				}
				else if(g_jumpHoldCounter == 21)
				{
					m_luna.m_move.m_posY = g_block[i].m_move.m_posY - m_luna.m_chip.m_center.y - g_block[i].m_chip.m_center.y;
					g_intersect_TOP = true;
				}
				
			}
	
		}
		else // 接着していなければ
		{
			g_intersect_TOP = false;
		}
		}
	}
}


//=============================================================================
//
//
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsLunaAndBlocksBottom()
{
	//
	// ここは下側の判定！
	//

	// 生存している敵全てと衝突判定を行う

		// スクリーン上でのそれぞれの短形の位置を計算する
	for(int i = 0; i < MAX_BLOCK ; i++)
	{
		if(g_block[i].m_activeFlag == true)
		{
		// 自機の短形を計算！・ｗ・
		RECT rectA;
		rectA.left = g_lunaBody[3].m_move.m_posX - g_lunaBody[3].m_chip.m_center.x + g_lunaBody[3].m_body.left;
		rectA.top = g_lunaBody[3].m_move.m_posY + g_lunaBody[3].m_chip.m_center.y - g_lunaBody[3].m_body.top;
		rectA.right = g_lunaBody[3].m_move.m_posX - g_lunaBody[3].m_chip.m_center.x + g_lunaBody[3].m_body.right;
		rectA.bottom = g_lunaBody[3].m_move.m_posY + g_lunaBody[3].m_chip.m_center.y - g_lunaBody[3].m_body.bottom;
		
		// 敵機の短形を計算
		RECT rectB;
		rectB.left = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.left;
		rectB.top = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.top;
		rectB.right = g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x + g_block[i].m_body.right;
		rectB.bottom = g_block[i].m_move.m_posY + g_block[i].m_chip.m_center.y - g_block[i].m_body.bottom;
		
		// 短形同士の重なりを判定
		if( collisionRect(&rectA, &rectB) == true && ( g_jumpHoldCounter == 0 || g_jumpHoldCounter == 21))
		{
						
			if(g_jumpHoldCounter == 0 || g_jumpHoldCounter == 21)
			{
				if(m_luna.m_move.m_posY - m_luna.m_chip.m_center.y >= g_block[i].m_move.m_posY - g_block[i].m_chip.m_center.y)
				{
					m_luna.m_move.m_posY = g_block[i].m_move.m_posY + m_luna.m_chip.m_center.y + g_block[i].m_chip.m_center.y - 1;
					m_luna.m_move.m_velX = 0.0f;
				}
			}


					if(m_lunaAnimation!=kLunaAnimation::LAND_RIGHT || m_lunaAnimation!=kLunaAnimation::LAND_LEFT)
					{
						// 右向き用
						if (m_LunaMuki == RIGHT)
						{

							if(doubleLandFlag2 == false )
							{

								// 多重処理防止・着地効果音再生・アニメーションを着地へ
								doubleLandFlag2 = true;
								
								if(dashJumpFlag || jumpFlag == true )
								{
									SimpleAudioEngine::getInstance()->playEffect("land.wav",false);
									m_lunaAnimation = kLunaAnimation::LAND_RIGHT;
								}
								
								
								
								/*
								if((m_luna.m_move.m_posX) <= (g_block[i].m_move.m_posX))
								{
									if((m_luna.m_move.m_posX) <= (g_block[i].m_move.m_posX - g_block[i].m_chip.m_center.x / 2))
									{
										if(IsKeyPressed(KEY_FLAG::C_KEY))
										{
											m_luna.m_chip.m_center.x = 5 ;
											m_luna.m_move.m_posX += 32;
										}
									}
									
								}
								 */
								// 着地判定
								// 地面判定がオンなら
								// 接地していればジャンプフラグを下ろす
								jumpFlag = false;
								g_checkStandGround = 2;
								//doubleJumpFlag = false;
								
								// ルナのX成分ベクトルをリセット
								m_luna.m_move.m_velX = 0.0f;
								
								// ダッシュジャンプフラグとC押し込み確認フラグを下ろす
								m_isPushedFlagC2 = false;
								dashJumpFlag = false;
								
								// ダッシュ値が３５以上ではない時 かつ ダッシュ値が１以上ではない時
								if(!(g_dashHoldCounter >= 35) && !(g_dashHoldCounter >= 1))
									// ダッシュフラグを下ろす
									dashFlag = false;
								
								// ジャンプの力を２５・ジャンプ値を０に指定
								jump_power = 25;
								g_jumpHoldCounter = 0;
								
								break;
								
							}
						}
						// これは左向き用
						else
						{

							if(doubleLandFlag2 == false)
							{
								doubleLandFlag2 = true;
								
								if(dashJumpFlag || jumpFlag == true )
								{
									SimpleAudioEngine::getInstance()->playEffect("land.wav",false);
									m_lunaAnimation = kLunaAnimation::LAND_LEFT;
								}
								
								// 着地判定
								// 地面判定がオンなら
								// 接地していればジャンプフラグを下ろす
								jumpFlag = false;
								g_checkStandGround = 2;
								//doubleJumpFlag = false;
								
								// ルナのX成分ベクトルをリセット
								m_luna.m_move.m_velX = 0.0f;
								
								// ダッシュジャンプフラグとC押し込み確認フラグを下ろす
								m_isPushedFlagC2 = false;
								dashJumpFlag = false;
								
								// ダッシュ値が３５以上ではない時 かつ ダッシュ値が１以上ではない時
								if(!(g_dashHoldCounter >= 35) && !(g_dashHoldCounter >= 1))
									// ダッシュフラグを下ろす
									dashFlag = false;
								
								// ジャンプの力を２５・ジャンプ値を０に指定
								jump_power = 25;
								g_jumpHoldCounter = 0;
								
								break;
								
							}
							
						}
						
					}
				}
	
			
			else 			// 接地していなければ
			{
				if(doubleLandFlag2 == true )
				{
					
	
					
					if(g_checkStandGround > 0)
						g_checkStandGround = 0;
				
					doubleLandFlag2 = false;
				}
			
			}
		}

	}
}

//
// 地面との着地判定
//
	
void GameMain::intersectsLunaAndGroundBottom()
{
	//
	// ここは下側の判定！
	//
	
	// 生存している敵全てと衝突判定を行う
	
	// スクリーン上でのそれぞれの短形の位置を計算する
	
	// 自機の短形を計算！・ｗ・
	RECT rectA;
	rectA.left = g_lunaBody[3].m_move.m_posX - g_lunaBody[3].m_chip.m_center.x + g_lunaBody[3].m_body.left;
	rectA.top = g_lunaBody[3].m_move.m_posY + g_lunaBody[3].m_chip.m_center.y - g_lunaBody[3].m_body.top;
	rectA.right = g_lunaBody[3].m_move.m_posX - g_lunaBody[3].m_chip.m_center.x + g_lunaBody[3].m_body.right;
	rectA.bottom = g_lunaBody[3].m_move.m_posY + g_lunaBody[3].m_chip.m_center.y - g_lunaBody[3].m_body.bottom;
	
	RECT rectB;
	rectB.left = g_pGround.m_move.m_posX - g_pGround.m_chip.m_center.x + g_pGround.m_body.left;
	rectB.top = g_pGround.m_move.m_posY + g_pGround.m_chip.m_center.y - g_pGround.m_body.top;
	rectB.right = g_pGround.m_move.m_posX - g_pGround.m_chip.m_center.x + g_pGround.m_body.right;
	rectB.bottom = g_pGround.m_move.m_posY + g_pGround.m_chip.m_center.y - g_pGround.m_body.bottom;
	

	
	//
	// 地面での接地判定
	//
	if( collisionRect(&rectA, &rectB) == true )
	{

		if((jumpFlag == false || dashFlag == false) && (g_jumpHoldCounter == 0 || g_jumpHoldCounter == 21))
		{
			m_luna.m_move.m_posY = g_pGround.m_move.m_posY + m_luna.m_chip.m_center.y + g_pGround.m_chip.m_center.y - 1;
			m_luna.m_move.m_velX = 0.0f;
		}
		
		if(m_lunaAnimation!=kLunaAnimation::LAND_RIGHT || m_lunaAnimation!=kLunaAnimation::LAND_LEFT)
		{
			
			// 右向き用
			if (m_LunaMuki == RIGHT)
			{
				if(doubleLandFlag == false)
				{
					
					// 多重処理防止・着地効果音再生・アニメーションを着地へ
					doubleLandFlag = true;
					
					if(dashJumpFlag || (jumpFlag == true && dashFlag == false))
					{
						SimpleAudioEngine::getInstance()->playEffect("land.wav",false);
						m_lunaAnimation = kLunaAnimation::LAND_RIGHT;
					}
					
					// 着地判定
					// 地面判定がオンなら
					
					// 接地していればジャンプフラグを下ろす
					jumpFlag = false;
					g_checkStandGround = 1;
					//doubleJumpFlag = false;
					
					// ルナのY成分位置を１２８に固定する
					// m_luna.m_move.m_posY = 128.0f;
					
					// ルナのX成分ベクトルをリセット
					m_luna.m_move.m_velX = 0.0f;
					
					// ダッシュジャンプフラグとC押し込み確認フラグを下ろす
					m_isPushedFlagC2 = false;
					dashJumpFlag = false;
					
					// ダッシュ値が１以上ではない時
					if(!(g_dashHoldCounter >= 1))
						// ダッシュフラグを下ろす
						dashFlag = false;
					
					// ジャンプの力を２５・ジャンプ値を０に指定
					jump_power = 25;
					g_jumpHoldCounter = 0;

				}
			}
			// これは左向き用
			else
			{
				if(doubleLandFlag == false )
				{
					doubleLandFlag = true;
					
					if(dashJumpFlag || (jumpFlag == true && dashFlag == false))
					{
						SimpleAudioEngine::getInstance()->playEffect("land.wav",false);
						m_lunaAnimation = kLunaAnimation::LAND_LEFT;
					}
					
					// 着地判定
					// 地面判定がオンなら
					
					// 接地していればジャンプフラグを下ろす
					jumpFlag = false;
					g_checkStandGround = 1;
					//doubleJumpFlag = false;
					
					// ルナのX成分ベクトルをリセット
					m_luna.m_move.m_velX = 0.0f;
					
					// ダッシュジャンプフラグとC押し込み確認フラグを下ろす
					m_isPushedFlagC2 = false;
					dashJumpFlag = false;
					
					// ダッシュ値が３５以上ではない時 かつ ダッシュ値が１以上ではない時
					
					if(!(g_dashHoldCounter >= 35) && !(g_dashHoldCounter >= 1))
						// ダッシュフラグを下ろす
						dashFlag = false;
					
					// ジャンプの力を２５・ジャンプ値を０に指定
					jump_power = 25;
					g_jumpHoldCounter = 0;
					
					
				}
			}
		}
	}
	else //if ( (collisionRect(&rectA, &rectB) == false) && g_checkStandGround != 0)			// 接地していなければ
	{
		if(doubleLandFlag == true )
		{
			if(dashFlag == true)
			{
				//dashFlag = false;
				//g_jumpHoldCounter =21;
			}
			
			scroolFlagRight = false;
			scroolFlagLeft = false;
			
			if(g_checkStandGround > 0)
				g_checkStandGround = 0;

			doubleLandFlag = false;
		}
	}


}
//=============================================================================
//	intersectsEnemyAndMyShip
//		敵機と自機の衝突判定処理
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsEnemyAndMyShip()
{
	
	
}

//=============================================================================
//	intersectsEnemyBulletAndMyShip
//		敵弾と自機の衝突判定処理
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::intersectsEnemyBulletAndMyShip()
{
	
}

//======================================================================================
//	IsInArea
//		キャラクターが指定した領域内にあるかどうかを調べる
//--------------------------------------------------------------------------------------
//	INPUT:	CHARACTER* pCharacter	キャラクター
//			RECT* pCharB			領域
//	OUTPUT:	bool					true	領域内にある
//									false	領域内にない
//======================================================================================
bool GameMain::isInArea(CCharacter* pChr, const RECT& area)
{
	int left	= (int)pChr->m_move.m_posX - pChr->m_chip.m_center.x;
	int top		= (int)pChr->m_move.m_posY + pChr->m_chip.m_center.y;
	int right	= (int)pChr->m_move.m_posX + pChr->m_chip.m_center.x;
	int bottom	= (int)pChr->m_move.m_posY - pChr->m_chip.m_center.y;
	
	return (left < area.right) && (bottom < area.top) && (right > area.left) && (top > area.bottom);
}


// ルナのアニメーションを制御する
// switch分岐で対応したアニメーションに切り替える
//=============================================================================
//	lunaAnimation()
//		ルナのアニメーションを全てこの関数で制御する
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::lunaAnimation()
{
	// ルナが右向きの時のアニメーション
	if (m_LunaMuki == RIGHT)
	{
		switch (m_lunaAnimation) {
				
				//
				// 右向き待機
				//
			case kLunaAnimation::WAIT_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 0;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
							
				break;
				
				//
				// 右向き歩行
				//
			case kLunaAnimation::WALK_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
				
				break;

				//
				// 右向きふぉーすあろー
				//
			case kLunaAnimation::SHOT_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 256+256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
				
				break;
				
				//
				// 右向きジャンプ
				//
			case kLunaAnimation::JUMP_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 256+256 +256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 3 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 3;
				}
				else
				{
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					m_luna.m_animeCounter++;
				}
				
				break;

				//
				// 右向き落下
				//
			case kLunaAnimation::FALL_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 256+256 +256 +256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 3 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 3;
				}
				else
				{
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					m_luna.m_animeCounter++;
				}
				
				break;
				
				//
				// 右向き着地
				//
			case kLunaAnimation::LAND_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 256+256 +256 +256 + 256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 2 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
				}
				else
				{
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					m_luna.m_animeCounter++;
				}
				
				break;
				
				//
				// 右向きダッシュ
				//
			case kLunaAnimation::DASH_RIGHT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 1536;
				//m_luna.m_chip.m_texPos.x = 128 * (m_luna.m_animeCounter /4);
				
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 2 * 2)
				{
					m_luna.m_animeCounter = 2;
					// 戻すの！・ｗ・
					if (g_dashHoldCounter == 35){
						m_lunaAnimation = kLunaAnimation::WAIT_RIGHT;
						
					}
				}
				else
				{
					// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
					m_luna.m_animeCounter++;
				}
				
				break;
				
			default:
				break;
		}
	}
	
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//
	// ここから左向き・ｗ・
	//
	
	if (m_LunaMuki == LEFT)
	{
		switch (m_lunaAnimation)
		{
				
				//
				// 左向き待機
				//
			case kLunaAnimation::WAIT_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 128;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
				
				break;
				
				//
				// 左向き歩行
				//
			case kLunaAnimation::WALK_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
				
				break;
				
				//
				// 左向きふぉーすあろー
				//
			case kLunaAnimation::SHOT_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384+256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				m_luna.m_animeCounter++;
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 8 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 0;
				}
				
				break;
				
				//
				// 左向きジャンプ
				//
			case kLunaAnimation::JUMP_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384+256 +256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 3 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 3;
				}
				else
				{
					m_luna.m_animeCounter++;
				}
				
				break;
				
				//
				// 左向きジャンプ
				//
			case kLunaAnimation::FALL_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384+256 +256 + 256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 3 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_luna.m_animeCounter = 3;
				}
				else
				{
					m_luna.m_animeCounter++;
				}
				
				break;
				
				
				//
				// 左向き着地
				//
			case kLunaAnimation::LAND_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384+256 +256 + 256 + 256;
				m_luna.m_chip.m_texPos.x = 64 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 2 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
				}
				else
				{
					m_luna.m_animeCounter++;
				}
				
				break;
				
				//
				// 左向きダッシュ
				//
			case kLunaAnimation::DASH_LEFT:
				// アイテムチップの描画をX軸の数値だけ加算していく
				// 最後に割る数値はフレーム数で、これを割ることによりアニメーション速度が変化する
				m_luna.m_chip.m_texPos.y = 384+256 +256 + 256 + 256 +128 + 64;
				// m_luna.m_chip.m_texPos.x = 128 * (m_luna.m_animeCounter / g_animationSpeed);
				
				// CHARACTERクラス型のアニメーションカウンタをインクリメントしていく
				
				
				// もしアニメーションカウンタが３以上になればアニメーションカウンタを０に
				if(m_luna.m_animeCounter >= 2 * g_animationSpeed)
				{
					// 戻すの！・ｗ・
					if (g_dashHoldCounter == 35)
					{
						m_lunaAnimation = kLunaAnimation::WAIT_LEFT;
					}
					m_luna.m_animeCounter = 2;
				}
				else
				{
					m_luna.m_animeCounter++;
				}
				
				break;

			default:
				break;
		}

	}
}

/*
// ルナの立ち絵を切り替えるよん
void GameMain::lunaFaceAnimation()
{
	switch (m_lunaFace)
	{
		case NOMAL_SMILE:
			setChip(&g_lunaFace.m_chip, 0, 0, 396, 488, 198, 244);
			break;
			
		case NOMAL_SMILE_CLOSE_EYES:
			setChip(&g_lunaFace.m_chip, 396*1, 0, 396, 488, 198, 244);
			break;
			
		case HAND_SMILE:
			setChip(&g_lunaFace.m_chip, 396*2, 0, 396, 488, 198, 244);
			break;
		
		case HAND_SMILE_CLOSE_EYES:
			setChip(&g_lunaFace.m_chip, 396*3, 0, 396, 488, 198, 244);
			break;
		
		case DEF_CRY:
			setChip(&g_lunaFace.m_chip, 396*4, 0, 396, 488, 198, 244);
			break;
			
		case DEF_HAND_SMILE:
			setChip(&g_lunaFace.m_chip, 396*5, 0, 396, 488, 198, 244);
			break;
			
		case DEF_HAND_TROUBLE:
			setChip(&g_lunaFace.m_chip, 396*6, 0, 396, 488, 198, 244);
			break;
			
		default:
			break;
	}
}
*/

//
// デバッグ用にテキストを表示させておく必要がある
// 少なくともFPS、処理速度、描画オブジェクト数は必須
//=============================================================================
//		debug()
//		デバッグ用のデータを出力する関数
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::debug()
{
	if(CCLayer::init())
	{
		// デバッグ用にテキストを表示させておく
		// ジャンプ値
		LabelTTF* levelLabel10 = LabelTTF::create("ジャンプ値", "arial", 15);
		//levelLabel10->setPosition(90, 600);
		levelLabel10->setPosition(650, 690);
		levelLabel10->setTag(10);
		levelLabel10->setColor(Color3B(0, 0, 0));
		this->addChild(levelLabel10);
		
		LabelTTF* pointLabel11 =CCLabelTTF::create("0", "arial", 15);
		pointLabel11->setPosition(650+100, 690);
		pointLabel11->setTag(11);
		pointLabel11->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel11);
		
		// チャージ値
		LabelTTF* levelLabel12 = LabelTTF::create("チャージ値", "arial", 15);
		levelLabel12->setPosition(650, 670);
		levelLabel12->setTag(12);
		levelLabel12->setColor(Color3B(0, 0, 0));
		this->addChild(levelLabel12);
		
		LabelTTF* pointLabel13 =CCLabelTTF::create("0", "arial", 15);
		pointLabel13->setPosition(650+100, 670);
		pointLabel13->setTag(13);
		pointLabel13->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel13);
		
		// ダッシュ値
		LabelTTF* levelLabel14 = LabelTTF::create("ダッシュ値", "arial", 15);
		levelLabel14->setPosition(650, 650);
		levelLabel14->setTag(14);
		levelLabel14->setColor(Color3B(0, 0, 0));
		this->addChild(levelLabel14);
		
		LabelTTF* pointLabel15 =CCLabelTTF::create("0", "arial", 15);
		pointLabel15->setPosition(650+100, 650);
		pointLabel15->setTag(15);
		pointLabel15->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel15);
		
		// ジャンプフラグ
		LabelTTF* levelLabel16 = LabelTTF::create("ジャンプF", "arial", 15);
		levelLabel16->setPosition(820, 690);
		levelLabel16->setTag(16);
		levelLabel16->setColor(Color3B(0, 0, 0));
		this->addChild(levelLabel16);
		
		LabelTTF* pointLabel17 =CCLabelTTF::create("0", "arial", 15);
		pointLabel17->setPosition(820 + 100, 690);
		pointLabel17->setTag(17);
		pointLabel17->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel17);
		
		// ダッシュフラグ
		LabelTTF* levelLabel18 = LabelTTF::create("ダッシュF", "arial", 15);
		levelLabel18->setPosition(820, 670);
		levelLabel18->setTag(18);
		levelLabel18->setColor(Color3B(0, 0, 0));
		this->addChild(levelLabel18);
		
		LabelTTF* pointLabel19 =CCLabelTTF::create("0", "arial", 15);
		pointLabel19->setPosition(820 + 100, 670);
		pointLabel19->setTag(19);
		pointLabel19->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel19);
		
		// 接地判定
		LabelTTF* pointLabel20 =CCLabelTTF::create("接地判定", "arial", 15);
		pointLabel20->setPosition(820, 650);
		pointLabel20->setTag(20);
		pointLabel20->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel20);
		
		LabelTTF* pointLabel21 =CCLabelTTF::create("0", "arial", 15);
		pointLabel21->setPosition(820+100, 650);
		pointLabel21->setTag(21);
		pointLabel21->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel21);
		
		// 左判定
		LabelTTF* pointLabel22 =CCLabelTTF::create("左判定", "arial", 15);
		pointLabel22->setPosition(820, 630);
		pointLabel22->setTag(22);
		pointLabel22->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel22);
		
		LabelTTF* pointLabel23 =CCLabelTTF::create("0", "arial", 15);
		pointLabel23->setPosition(820+100, 630);
		pointLabel23->setTag(23);
		pointLabel23->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel23);
		
		// 右判定
		LabelTTF* pointLabel24 =CCLabelTTF::create("右判定", "arial", 15);
		pointLabel24->setPosition(820, 610);
		pointLabel24->setTag(24);
		pointLabel24->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel24);
		
		LabelTTF* pointLabel25 =CCLabelTTF::create("0", "arial", 15);
		pointLabel25->setPosition(820+100, 610);
		pointLabel25->setTag(25);
		pointLabel25->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel25);
		
		// 天井判定
		LabelTTF* pointLabel26 =CCLabelTTF::create("天井判定", "arial", 15);
		pointLabel26->setPosition(820, 590);
		pointLabel26->setTag(26);
		pointLabel26->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel26);
		
		LabelTTF* pointLabel27 =CCLabelTTF::create("0", "arial", 15);
		pointLabel27->setPosition(820+100, 590);
		pointLabel27->setTag(27);
		pointLabel27->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel27);
		
		// 壁張り付き 左判定
		LabelTTF* pointLabel28 =CCLabelTTF::create("壁張左判定", "arial", 15);
		pointLabel28->setPosition(820, 570);
		pointLabel28->setTag(28);
		pointLabel28->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel28);
		
		LabelTTF* pointLabel29 =CCLabelTTF::create("0", "arial", 15);
		pointLabel29->setPosition(820+100, 570);
		pointLabel29->setTag(29);
		pointLabel29->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel29);

		// 壁張り付き 右判定
		LabelTTF* pointLabel30 =CCLabelTTF::create("壁張右判定", "arial", 15);
		pointLabel30->setPosition(820, 550);
		pointLabel30->setTag(30);
		pointLabel30->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel30);
		
		LabelTTF* pointLabel31 =CCLabelTTF::create("0", "arial", 15);
		pointLabel31->setPosition(820+100, 550);
		pointLabel31->setTag(31);
		pointLabel31->setColor(Color3B(0, 0, 0));
		this->addChild(pointLabel31);
	}
}

//
// デバッグテキストの描画を更新する
// ここを管理することでバグの発見が非常にわかりやすくなる
// 要素が追加されたらここを追加するようにしよう
//=============================================================================
// debugUpdate関数
//		出力した数値を更新（デバッグ用）
//	-----------------------------------------------------------------------
//	OUTPUT:	void
//=============================================================================
void GameMain::debugUpdate()
{
	LabelTTF* label11 = (LabelTTF *)this->getChildByTag(11);
	// int型からCCStringに変換
	CCString* points11 = CCString::createWithFormat("%d", g_jumpHoldCounter);
	// スコアポイントの表示を更新
	label11 -> setString(points11->getCString());
	
	
	
	LabelTTF* label13 = (LabelTTF *)this->getChildByTag(13);
	// int型からCCStringに変換
	CCString* points13 = CCString::createWithFormat("%d", g_chargeHoldCounter);
	// スコアポイントの表示を更新
	label13 -> setString(points13->getCString());
	
	
	
	LabelTTF* label15 = (LabelTTF *)this->getChildByTag(15);
	// int型からCCStringに変換
	CCString* points15 = CCString::createWithFormat("%d", g_dashHoldCounter);
	// スコアポイントの表示を更新
	label15 -> setString(points15->getCString());
	
	
	LabelTTF* label17 = (LabelTTF *)this->getChildByTag(17);
	// int型からCCStringに変換
	CCString* points17 = CCString::createWithFormat("%d", jumpFlag);
	// スコアポイントの表示を更新
	label17 -> setString(points17->getCString());
	
	
	LabelTTF* label19 = (LabelTTF *)this->getChildByTag(19);
	// int型からCCStringに変換
	CCString* points19 = CCString::createWithFormat("%d", dashFlag);
	// スコアポイントの表示を更新
	label19 -> setString(points19->getCString());
	
	
	LabelTTF* label20 = (LabelTTF *)this->getChildByTag(21);
	// int型からCCStringに変換
	CCString* points20 = CCString::createWithFormat("%d", g_checkStandGround);
	// スコアポイントの表示を更新
	label20 -> setString(points20->getCString());
	
	
	LabelTTF* label23 = (LabelTTF *)this->getChildByTag(23);
	// int型からCCStringに変換
	CCString* points23 = CCString::createWithFormat("%d", g_intersect_LEFT);
	// スコアポイントの表示を更新
	label23 -> setString(points23->getCString());
	
	LabelTTF* label25 = (LabelTTF *)this->getChildByTag(25);
	// int型からCCStringに変換
	CCString* points25 = CCString::createWithFormat("%d", g_intersect_RIGHT);
	// スコアポイントの表示を更新
	label25 -> setString(points25->getCString());
	
	LabelTTF* label27 = (LabelTTF *)this->getChildByTag(27);
	// int型からCCStringに変換
	CCString* points27 = CCString::createWithFormat("%d", g_intersect_TOP);
	// スコアポイントの表示を更新
	label27 -> setString(points27->getCString());
	
	LabelTTF* label29 = (LabelTTF *)this->getChildByTag(29);
	// int型からCCStringに変換
	CCString* points29 = CCString::createWithFormat("%d", wallStickLeft);
	// スコアポイントの表示を更新
	label29 -> setString(points29->getCString());
	
	LabelTTF* label31 = (LabelTTF *)this->getChildByTag(31);
	// int型からCCStringに変換
	CCString* points31 = CCString::createWithFormat("%d", wallStickRight);
	// スコアポイントの表示を更新
	label31 -> setString(points31->getCString());

}
