
#ifndef __Stg14__LunaFace__
#define __Stg14__LunaFace__

#include "cocos2d.h"



struct _tagTEXTURE;
typedef struct _tagTEXTURE TEXTURE;

struct _tagCHIP;
typedef struct _tagCHIP CHIP;

// ルナのUI表情のタイプ 列挙
enum kLunaFaceType
{
	NO_FACE				= 0,
	
	// ポーズ ノーマル
	NOMAL_SMILE,
	NOMAL_SMILE_CLOSE_EYES,
	
	// ポーズ 両手合わせ
	HAND_SMILE,
	HAND_SMILE_CLOSE_EYES,
	
	// デフォルメ
	DEF_CRY,
	
	// デフォルメ ポーズ両手合わせ
	DEF_HAND_SMILE,
	DEF_HAND_TROUBLE,
	
};


class CLunaFace
{
	// ルナの立ち絵テクスチャ
	TEXTURE* m_lunaFaceTexture;
	cocos2d::Sprite* m_lunaFace;
	
	// ルナの表情
	kLunaFaceType m_lunaFaceType;
	
public:
	CLunaFace();
	~CLunaFace();
	
	cocos2d::Sprite* getSprite();
	void setLunaOpacity(float Opacity);
	void update(double deltaTime);


	
	
};
#endif /* defined(__Stg14__LunaFace__) */
