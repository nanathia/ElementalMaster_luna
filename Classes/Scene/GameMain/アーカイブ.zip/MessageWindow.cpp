#include "MessageWindow.h"
#include "GameMain.h"
#include "Constants.h"
#include "ImageUtil.h"
#include "Character.h"
#include "InputManager.h"
#include "SimpleAudioEngine.h"
#include "LunaFace.h"
#include "WindowState.h"

using namespace std;
using namespace CocosDenshion;

// 多少のコメントサボりは、新技術「pragma mark」と書いた。

// まとめクラス。
#pragma mark ---まとめ。---

// ウィンドウコンソール、コンストラクタでメッセージウィンドウ２種、インスタンスを生成
WindowConsole::WindowConsole():
m_Name_win(0),
m_Message_win(0),
m_Message(0),
m_lunaFace(0),
m_windowState(0)
{
	m_Message_win = new CMessageWindow;
    m_Name_win = new CNameWindow;
	m_lunaFace = new CLunaFace;
	m_windowState = new WindowState(this);
	
}

// デストラクタ
WindowConsole::~WindowConsole(){
	// メンバである各ウィンドウをデリート
	// その後、NULLポインタを入れておく
    delete m_Message_win;
    m_Message_win = 0;
    delete m_Name_win;
    m_Name_win = 0;
	delete m_lunaFace;
    m_lunaFace = 0;
	// メッセージがデリートされてなければデリートします
    if(m_Message) delete m_Message;
}

// ウィンドウコンソール、更新処理
void WindowConsole::update(double deltaTime){
	m_windowState->update(deltaTime);
	// それぞれのインスタンスから更新処理を呼び出す
    m_Message_win->update(deltaTime);
    m_Name_win->update(deltaTime);
	// m_lunaFace->update(deltaTime);
	// 呼び出し後、isVisibled()が呼び出されてカウンタが1.0になったらtrueを返すのでtrueを受け取ったらメッセージ更新処理開始
    if(m_Message && m_Message_win->isVisibled()) m_Message->update(deltaTime);
}

// ウィンドウコンソール nextLabel
void WindowConsole::nextLabel(const std::string &str){
	// まずは文字列の削除とNULLを代入
    if(m_Message) delete m_Message;
    m_Message = 0;
	// そして新たに生成
	// コンストラクタに文字列と座標を入れてコンストラクタ呼び出し
    m_Message = new CMessage(str, Point(30, 200));
}

void WindowConsole::setCharacterName(const std::string& str){
    m_Name_win->setName(str);
}


// １枚かまーす・ｗ・
CNameWindow* WindowConsole::getNameWindow()
{
	return m_Name_win;
}

CMessageWindow* WindowConsole::getMessageWindow()
{
	return m_Message_win;
}

CMessage* WindowConsole::getMessage()
{
	return m_Message;
}

CLunaFace* WindowConsole::getLunaSprite()
{
	return m_lunaFace;
}


// メッセージ窓
// 必殺プラグマ
// コンストラクタにNULLポインタ・ｗ・ｂ
#pragma mark ---メッセージ窓---
CMessageWindow::CMessageWindow():
m_rect(),
m_time(0),
m_Sprite(0),
m_tex(0)
{
	// テクスチャ生成
    m_tex = new TEXTURE;
	
	// loadImage()を無理やり使用
	loadImage("MessageBack2.png", m_tex);
	// 画面サイズを取得
    Size ImSize = m_tex->m_pTexture->getContentSize();
    // テクスチャのセンター位置を指定
	m_rect.origin = ImSize/2;
	// スプライトを指定
	m_Sprite = Sprite::createWithTexture(m_tex->m_pTexture);
	// 描画
	gGameMain->addToScreen(m_Sprite);
	
	
	// オリジンを元に描画設定
	m_Sprite->setPosition(302, 130);//m_rect.origin);
	m_Sprite->setOpacity(200);
	m_Sprite->setZOrder(5);
    m_Sprite->setVisible(true);
}

CMessageWindow::~CMessageWindow(){
	// デストラクタでウィンドウを消去後、NULLを指定
	if(m_Sprite) m_Sprite->removeFromParentAndCleanup(true);
    m_Sprite = 0;
	
	// テクスチャの解放後、NULL
    delete m_tex;
    m_tex = 0;
}
void CMessageWindow::update(double deltaTime){
	// ウィンドウのびゅいーんをフレームレートに依存
    m_time += deltaTime;
	
	// びゅいーん時間は1.0以上行かないようにする
    if(m_time >= 1.0){
        m_time = 1.0;
    }
	// スプライト(x, y)大きさをm_timeに依存、と等倍
    //m_Sprite->setScale(m_time, 1.0);
}
bool CMessageWindow::isVisibled(){
	// m_time が 1.0 になれば３項式でtrue を返す
    return m_time == 1.0 ? true: false;
}

cocos2d::Sprite* CMessageWindow::getSprite()
{
	return m_Sprite;
}

TEXTURE* CMessageWindow::getTex()
{
	return m_tex;
}
void CMessageWindow::setScale(float scaleX){
    m_Sprite->setScale(scaleX, 1.0);
}

// キャラクター名前窓（名前、窓）
#pragma mark ---名前窓---
CNameWindow::CNameWindow():
m_WindowTex(0),
m_Window(0),
m_rect(0, 150, 0, 0),
m_label(0)
{
	// テクスチャー型を new しまふ
    m_WindowTex = new TEXTURE;
	// 無理やりイメージの読み込み
	loadImage("MessageName.png", m_WindowTex);
	// テクスチャの生成
	m_Window = Sprite::createWithTexture(m_WindowTex->m_pTexture);
	// gGameMain に addChild しまふ
	gGameMain->addToScreen(m_Window);
	
    Size ImSize = m_WindowTex->m_pTexture->getContentSize();
    ImSize.height += 500;
    m_Window->setPosition(140, 275);//Point(ImSize/2));
	m_Window->setZOrder(5);
	m_Window->setOpacity(200);
    // とりあえずはルナの名前を入れておく
    this->setName("ルナ");
}

CNameWindow::~CNameWindow(){
	// ネームウィンドウの解放
	m_Window->removeFromParentAndCleanup(true);
	// デリート後、NULLポインタを指定
	delete m_WindowTex;
	m_WindowTex = 0;
	
	// メッセージラベルをデリート後、NULLポインタを指定
    if(m_label) m_label->removeFromParentAndCleanup(true);
    m_label = 0;
}

void CNameWindow::setName(const std::string& str){
	// NULLポインタを指定していない場合
	if(m_label){
		m_label->removeFromParentAndCleanup(true);
		m_label = 0;
		// とりあえず解放
	}
	
	// 描画
	m_label = LabelTTF::create(str.c_str(), "arial", 25);
    gGameMain->addToScreen(m_label);
	// 位置を指定
    m_label->setPosition(50, 275);
	// Ｚオーダを指定
    m_label->setZOrder(6);
}

void CNameWindow::update(double deltaTime){
	
	// ネームウィンドウの更新処理を書く
}

cocos2d::Sprite* CNameWindow::getSprite()
{
	return m_Window;
}

// 一文字。
// 初期化ご、NULLを入れておく
#pragma mark ---一文字---
CChar::CChar(const std::string& str, const Point& pos):
m_label(0),
m_time(0),
m_next(0),
m_prev(0),
m_point(pos){
	// 描画
    m_label = CCLabelTTF::create(str.c_str(), "arial", 25);
    gGameMain->addToScreen(m_label);
	
    // 描画位置を指定
	m_label->setPosition(pos);
	m_label->setOpacity(0);
    //m_label->setVisible(false);
	m_label->setZOrder(6);
}

CChar::~CChar(){
	// デストラクタ
    if(m_label) m_label->removeFromParentAndCleanup(true);
    m_label = 0;
}

void CChar::setNext(CChar* next){
    m_next = next;
}

void CChar::setPrev(CChar* prev){
    m_prev = prev;
}

void CChar::update(double deltaTime){
    if(m_prev){
        // 前の文字があるときは前が「行っていいよ」って言うまで待つのよー。
		/// つまりGOフラグを返すということか
        if(!m_prev->isEnableNextLunch()){
            return;
        }
    }
    m_time += deltaTime*2;
    if(m_time >= 1){
        m_time = 1;
    }
    if(m_label){
		//m_label->setVisible(true);
		m_label->setOpacity(m_time*255);
	}
}

bool CChar::isEnableNextLunch(){
    // ０．２秒たったら次の文字が出るのよー。
    return m_time >= 0.27 ? true: false;
}


// 一回に流れるメッセージ。
#pragma mark ---メッセージ---
CMessage::CMessage(const std::string& str, const Point& point):
m_point(point)
{
    int size = (int)str.size();
    // 最大横文字数１１に。
	/// あるみが１８に変更
    const int widthMax = 18;
	int x = 0;
	int y = 1;
    // １文字ずつ生成よ。
    for(int i = 0; i < size; i+=3){
        Point pos(x%((3*widthMax)*10)+15, ((i+y)/(3*widthMax)*-32)+10);
        pos += point;
        char character[4];

        character[0] = str.c_str()[i];
        character[1] = str.c_str()[i+1];
        character[2] = str.c_str()[i+2];
        character[3] = '\0';
		
		if(strcmp(character,"嬲")==0)
		{
			y += 25;
			x = 0;
			continue;
		}
		else{
			CChar* new_c = new CChar(character, pos);
			
			if(i != 0){
				// .back() っていうのは一番後ろって意味よー。
				m_characters.back()->setNext(new_c);
				new_c->setPrev(m_characters.back());
			}
		m_characters.push_back(new_c);
		}
			x += 25;
    }
    
}

CMessage::~CMessage(){
    // 強参照とか弱参照とか。そういうの使って、delete。
    int size = (int)m_characters.size();
    for(int i = 0; i < size; i++){
        delete m_characters[i];
        m_characters[i] = 0;
    }
}

void CMessage::update(double deltaTime){
    // 強参照とか弱参照とか。そういうの使って、delete。
    int size = (int)m_characters.size();
    for(int i = 0; i < size; i++){
        m_characters[i]->update(deltaTime);
    }
}

