

#include "LunaFace.h"
#include "ImageUtil.h"
#include "Constants.h"
#include "Character.h"
// #include "Chip.h"
#include "GameMain.h"
using namespace cocos2d;

#pragma mark --- ルナ立ち絵 定義 ---

CLunaFace::CLunaFace():
m_lunaFaceTexture(0),
m_lunaFace(0)
{
	m_lunaFaceTexture = new TEXTURE;
	m_lunaFaceType = kLunaFaceType::NOMAL_SMILE;
    //loadImage("lunaFace.png", this->m_lunaFaceTexture);
	m_lunaFace = Sprite::create("lunaFace.png", CCRectMake(0, 0, 396 * m_lunaFaceType, 488));
	
	//Size spriteSize = m_lunaFaceTexture->m_pTexture->getContentSize();
	
	//m_lunaRect.origin = spriteSize/7;
	
	//m_lunaFace = Sprite::createWithTexture(m_lunaFaceTexture->m_pTexture);
	
	
	
	gGameMain->addChild(m_lunaFace);
	
	// 初期位置と透過値を指定
	
	m_lunaFace->setZOrder(9);
	m_lunaFace->setOpacity(0);
	m_lunaFace->setPosition(760.0f, -240.0f);
	m_lunaFace->setVisible(false);
}

CLunaFace::~CLunaFace(){
	// ルナの立ち絵の解放
	this->getSprite()->removeFromParent() ;
	delete m_lunaFaceTexture;
	m_lunaFaceTexture = 0;
}

cocos2d::Sprite* CLunaFace::getSprite()
{
	return m_lunaFace;
}

void CLunaFace::update(double deltaTime)
{
	
}

void CLunaFace::setLunaOpacity(float Opacity)
{
	m_lunaFace->setOpacity(Opacity);
}